"use client"

export interface DiseaseDataEntry {
  id: string
  region: string
  district: string
  year: number
  measles_cases: number
  malaria_cases: number
  cholera_cases: number
  population: number
  date_added: string
  added_by: string
  source: string
  notes?: string
}

// CSV data structure from your offer.csv file
interface CSVDataEntry {
  region: string
  district: string
  pcode: string
  admin0: string
  year: number
  n: number
  n_u5: number
  n_died: number
  n_died_u5: number
  p_time: number
  p_time_u5: number
  qualityScore: number
  hh_weights: number
  lhz_type: string
  Recall_Days: number
  cdi: number
  cdi_lag4: number
  cdi_lag5: number
  cdi_lag5_scn: number
  cdi_lag6: number
  dep_rate: number
  dep_rate_sqt: number
  dep_rate_sqt_scn: number
  pop_average: number
  pop_average_low: number
  pop_average_u5: number
  pop_average_u5_low: number
  pop_average_u5_upp: number
  pop_average_upp: number
  prop_idp: number
  prop_idp_scn: number
  rainfall: number
  rainfall_lag4: number
  rainfall_lag5: number
  rainfall_lag5_scn: number
  rainfall_lag6: number
  sam_admissions: number
  sam_admissions_rate: number
  sam_admissions_rate_lag1: number
  sam_admissions_rate_lag1_scn: number
  sam_admissions_rate_lag2: number
  tot_goat_cereal_smooth: number
  tot_goat_cereal_smooth_lag2: number
  measles_cases: number
  malaria_cases: number
  cholera_cases: number
}

class DataStorage {
  private storageKey = "disease_dashboard_data"
  private csvData: CSVDataEntry[] | null = null

  // Parse CSV data from your offer.csv file
  private parseCSV(csvText: string): CSVDataEntry[] {
    console.log("🔄 Starting CSV parsing...")
    console.log(`📄 CSV content preview (first 500 chars):`, csvText.substring(0, 500))

    const lines = csvText.trim().split("\n")
    console.log(`📊 Found ${lines.length} lines in CSV`)

    if (lines.length < 2) {
      console.error("❌ CSV has less than 2 lines")
      return []
    }

    // Detect separator
    let separator = ","
    if (lines[0].includes(";") && lines[0].split(";").length > lines[0].split(",").length) {
      separator = ";"
      console.log("📝 Using semicolon separator")
    } else if (lines[0].includes("\t")) {
      separator = "\t"
      console.log("📝 Using tab separator")
    } else {
      console.log("📝 Using comma separator")
    }

    const headers = lines[0].split(separator).map((h) => h.trim().replace(/"/g, ""))
    console.log(`📋 Headers (${headers.length}):`, headers.slice(0, 10).join(", ") + (headers.length > 10 ? "..." : ""))

    const data: CSVDataEntry[] = []

    for (let i = 1; i < lines.length; i++) {
      const values = lines[i].split(separator)
      const row: any = {}

      headers.forEach((header, index) => {
        const value = values[index]?.trim().replace(/"/g, "") || ""

        // Convert numeric fields
        if (
          [
            "year",
            "n",
            "n_u5",
            "n_died",
            "n_died_u5",
            "p_time",
            "p_time_u5",
            "qualityScore",
            "hh_weights",
            "Recall_Days",
            "cdi",
            "cdi_lag4",
            "cdi_lag5",
            "cdi_lag5_scn",
            "cdi_lag6",
            "dep_rate",
            "dep_rate_sqt",
            "dep_rate_sqt_scn",
            "pop_average",
            "pop_average_low",
            "pop_average_u5",
            "pop_average_u5_low",
            "pop_average_u5_upp",
            "pop_average_upp",
            "prop_idp",
            "prop_idp_scn",
            "rainfall",
            "rainfall_lag4",
            "rainfall_lag5",
            "rainfall_lag5_scn",
            "rainfall_lag6",
            "sam_admissions",
            "sam_admissions_rate",
            "sam_admissions_rate_lag1",
            "sam_admissions_rate_lag1_scn",
            "sam_admissions_rate_lag2",
            "tot_goat_cereal_smooth",
            "tot_goat_cereal_smooth_lag2",
            "measles_cases",
            "malaria_cases",
            "cholera_cases",
          ].includes(header)
        ) {
          row[header] = value !== "" && !isNaN(Number(value)) ? Number.parseFloat(value) : 0
        } else {
          row[header] = value || ""
        }
      })

      data.push(row as CSVDataEntry)
    }

    console.log(`✅ Successfully parsed ${data.length} rows`)
    console.log("📊 Sample row:", data[0])
    return data
  }

  // Load data from CSV file
  private async loadCSVData(): Promise<CSVDataEntry[]> {
    if (this.csvData) {
      console.log("📋 Using cached CSV data")
      return this.csvData
    }

    const possiblePaths = ["/data/offer.csv", "/public/data/offer.csv", "/data/dataset.csv", "/data/somalia_data.csv"]

    for (const path of possiblePaths) {
      try {
        console.log(`🔍 Trying to load CSV from: ${path}`)
        const response = await fetch(path)

        if (!response.ok) {
          console.log(`❌ ${path} not found (${response.status})`)
          continue
        }

        const csvText = await response.text()
        console.log(`✅ Successfully fetched ${path} (${csvText.length} characters)`)

        if (csvText.length < 100) {
          console.log(`⚠️ File too small: ${csvText.length} characters`)
          continue
        }

        this.csvData = this.parseCSV(csvText)

        if (this.csvData.length > 0) {
          console.log(`🎉 SUCCESS! Loaded ${this.csvData.length} records from ${path}`)
          return this.csvData
        }
      } catch (error) {
        console.error(`❌ Error loading ${path}:`, error)
      }
    }

    console.log("📝 No CSV found, using sample data")
    return this.getSampleData()
  }

  // Get sample data if CSV fails to load
  private getSampleData(): CSVDataEntry[] {
    console.log("📝 Loading sample data (CSV file not available)")
    return [
      {
        region: "Awdal",
        district: "Baki",
        pcode: "SO0101",
        admin0: "Somalia",
        year: 2023,
        n: 1250,
        n_u5: 425,
        n_died: 15,
        n_died_u5: 8,
        p_time: 12.5,
        p_time_u5: 18.2,
        qualityScore: 85.3,
        hh_weights: 1.2,
        lhz_type: "Pastoral",
        Recall_Days: 30,
        cdi: 0.45,
        cdi_lag4: 0.52,
        cdi_lag5: 0.48,
        cdi_lag5_scn: 0.51,
        cdi_lag6: 0.46,
        dep_rate: 2.1,
        dep_rate_sqt: 4.41,
        dep_rate_sqt_scn: 4.2,
        pop_average: 125000,
        pop_average_low: 118000,
        pop_average_u5: 25000,
        pop_average_u5_low: 23500,
        pop_average_u5_upp: 26500,
        pop_average_upp: 132000,
        prop_idp: 0.05,
        prop_idp_scn: 0.04,
        rainfall: 450,
        rainfall_lag4: 520,
        rainfall_lag5: 480,
        rainfall_lag5_scn: 510,
        rainfall_lag6: 460,
        sam_admissions: 125,
        sam_admissions_rate: 1.0,
        sam_admissions_rate_lag1: 1.2,
        sam_admissions_rate_lag1_scn: 1.1,
        sam_admissions_rate_lag2: 0.9,
        tot_goat_cereal_smooth: 2.5,
        tot_goat_cereal_smooth_lag2: 2.3,
        measles_cases: 111.91,
        malaria_cases: 12226.85,
        cholera_cases: 0.0,
      },
      {
        region: "Banadir",
        district: "Banadir",
        pcode: "SO0301",
        admin0: "Somalia",
        year: 2023,
        n: 15000,
        n_u5: 4800,
        n_died: 450,
        n_died_u5: 180,
        p_time: 30.0,
        p_time_u5: 37.5,
        qualityScore: 92.8,
        hh_weights: 2.5,
        lhz_type: "Urban",
        Recall_Days: 25,
        cdi: 0.65,
        cdi_lag4: 0.72,
        cdi_lag5: 0.68,
        cdi_lag5_scn: 0.71,
        cdi_lag6: 0.66,
        dep_rate: 1.2,
        dep_rate_sqt: 1.44,
        dep_rate_sqt_scn: 1.4,
        pop_average: 1500000,
        pop_average_low: 1420000,
        pop_average_u5: 300000,
        pop_average_u5_low: 285000,
        pop_average_u5_upp: 315000,
        pop_average_upp: 1580000,
        prop_idp: 0.15,
        prop_idp_scn: 0.12,
        rainfall: 600,
        rainfall_lag4: 680,
        rainfall_lag5: 640,
        rainfall_lag5_scn: 690,
        rainfall_lag6: 610,
        sam_admissions: 1200,
        sam_admissions_rate: 0.8,
        sam_admissions_rate_lag1: 1.0,
        sam_admissions_rate_lag1_scn: 0.9,
        sam_admissions_rate_lag2: 0.7,
        tot_goat_cereal_smooth: 3.5,
        tot_goat_cereal_smooth_lag2: 3.2,
        measles_cases: 577188.43,
        malaria_cases: 158099.25,
        cholera_cases: 659714.58,
      },
      {
        region: "Bari",
        district: "Bossaso",
        pcode: "SO0402",
        admin0: "Somalia",
        year: 2023,
        n: 8500,
        n_u5: 2700,
        n_died: 95,
        n_died_u5: 38,
        p_time: 11.2,
        p_time_u5: 14.1,
        qualityScore: 89.4,
        hh_weights: 1.8,
        lhz_type: "Urban",
        Recall_Days: 28,
        cdi: 0.58,
        cdi_lag4: 0.65,
        cdi_lag5: 0.61,
        cdi_lag5_scn: 0.64,
        cdi_lag6: 0.59,
        dep_rate: 1.5,
        dep_rate_sqt: 2.25,
        dep_rate_sqt_scn: 2.1,
        pop_average: 850000,
        pop_average_low: 800000,
        pop_average_u5: 170000,
        pop_average_u5_low: 160000,
        pop_average_u5_upp: 180000,
        pop_average_upp: 900000,
        prop_idp: 0.08,
        prop_idp_scn: 0.06,
        rainfall: 420,
        rainfall_lag4: 480,
        rainfall_lag5: 450,
        rainfall_lag5_scn: 490,
        rainfall_lag6: 430,
        sam_admissions: 680,
        sam_admissions_rate: 0.8,
        sam_admissions_rate_lag1: 1.0,
        sam_admissions_rate_lag1_scn: 0.9,
        sam_admissions_rate_lag2: 0.7,
        tot_goat_cereal_smooth: 3.2,
        tot_goat_cereal_smooth_lag2: 2.9,
        measles_cases: 98291.1,
        malaria_cases: 112030.3,
        cholera_cases: 275850.21,
      },
    ]
  }

  // Get all data entries (now loads from CSV)
  async getData(): Promise<CSVDataEntry[]> {
    return await this.loadCSVData()
  }

  // Get localStorage data entries (for user-added data)
  getLocalData(): DiseaseDataEntry[] {
    if (typeof window === "undefined") return []

    const data = localStorage.getItem(this.storageKey)
    return data ? JSON.parse(data) : []
  }

  // Add new data entry to localStorage
  addData(entry: Omit<DiseaseDataEntry, "id" | "date_added">): DiseaseDataEntry {
    const users = this.getLocalData()
    const newEntry: DiseaseDataEntry = {
      ...entry,
      id: Date.now().toString(),
      date_added: new Date().toISOString(),
    }

    users.push(newEntry)
    localStorage.setItem(this.storageKey, JSON.stringify(users))
    return newEntry
  }

  // Delete data entry from localStorage
  deleteData(id: string): boolean {
    const data = this.getLocalData()
    const filteredData = data.filter((entry) => entry.id !== id)

    if (filteredData.length === data.length) return false

    localStorage.setItem(this.storageKey, JSON.stringify(filteredData))
    return true
  }

  // Export data
  exportData(): string {
    return JSON.stringify(this.getLocalData(), null, 2)
  }

  // Import data
  importData(jsonData: string): boolean {
    try {
      const data = JSON.parse(jsonData)
      localStorage.setItem(this.storageKey, JSON.stringify(data))
      return true
    } catch {
      return false
    }
  }

  // Clear all localStorage data
  clearData(): void {
    localStorage.removeItem(this.storageKey)
  }
}

export const dataStorage = new DataStorage()

"use client"

export interface User {
  id: string
  email: string
  name: string
  role: "admin" | "researcher" | "viewer" | "supervisor" | "teacher"
  password: string // In real apps, this would be hashed
  createdAt: string
  class?: string
  position?: string
}

// Updated users for BIT28 project with correct admin
const DEFAULT_USERS: User[] = [
  {
    id: "1",
    email: "hussein.salad@simad.edu.so",
    name: "Hussein Ali Salad",
    role: "researcher",
    password: "hussein123",
    createdAt: new Date().toISOString(),
    class: "BIT28",
    position: "Lead Developer & Student",
  },
  {
    id: "2",
    email: "ahmed.muse@simad.edu.so",
    name: "Ahmed Muse Ahmed",
    role: "researcher",
    password: "ahmed123",
    createdAt: new Date().toISOString(),
    class: "BIT28",
    position: "Co-Developer & Partner",
  },
  {
    id: "3",
    email: "dr.abdi.jalil@simad.edu.so",
    name: "DR Abdi Jalil",
    role: "supervisor",
    password: "supervisor123",
    createdAt: new Date().toISOString(),
    class: "BIT28",
    position: "Project Supervisor",
  },
  {
    id: "4",
    email: "dr.ahmed.hassan@simad.edu.so",
    name: "DR Ahmed Hassan",
    role: "admin",
    password: "admin123",
    createdAt: new Date().toISOString(),
    class: "BIT28",
    position: "System Administrator",
  },
  {
    id: "5",
    email: "teacher@simad.edu.so",
    name: "Health Data Teacher",
    role: "teacher",
    password: "teacher123",
    createdAt: new Date().toISOString(),
    class: "BIT28",
    position: "Data Instructor",
  },
]

class AuthStorage {
  private storageKey = "disease_dashboard_users"

  // Initialize storage with default users
  private initializeStorage() {
    if (typeof window === "undefined") return

    const existingUsers = localStorage.getItem(this.storageKey)
    if (!existingUsers) {
      localStorage.setItem(this.storageKey, JSON.stringify(DEFAULT_USERS))
    }
  }

  // Get all users
  getUsers(): User[] {
    if (typeof window === "undefined") return DEFAULT_USERS

    this.initializeStorage()
    const users = localStorage.getItem(this.storageKey)
    return users ? JSON.parse(users) : DEFAULT_USERS
  }

  // Find user by email
  findUserByEmail(email: string): User | null {
    const users = this.getUsers()
    return users.find((user) => user.email.toLowerCase() === email.toLowerCase()) || null
  }

  // Add new user
  addUser(userData: Omit<User, "id" | "createdAt">): User {
    const users = this.getUsers()
    const newUser: User = {
      ...userData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
    }

    users.push(newUser)
    localStorage.setItem(this.storageKey, JSON.stringify(users))
    return newUser
  }

  // Update user
  updateUser(id: string, updates: Partial<User>): User | null {
    const users = this.getUsers()
    const userIndex = users.findIndex((user) => user.id === id)

    if (userIndex === -1) return null

    users[userIndex] = { ...users[userIndex], ...updates }
    localStorage.setItem(this.storageKey, JSON.stringify(users))
    return users[userIndex]
  }

  // Delete user
  deleteUser(id: string): boolean {
    const users = this.getUsers()
    const filteredUsers = users.filter((user) => user.id !== id)

    if (filteredUsers.length === users.length) return false

    localStorage.setItem(this.storageKey, JSON.stringify(filteredUsers))
    return true
  }

  // Authenticate user
  authenticate(email: string, password: string): User | null {
    const user = this.findUserByEmail(email)
    if (user && user.password === password) {
      return user
    }
    return null
  }

  // Check if email exists
  emailExists(email: string): boolean {
    return this.findUserByEmail(email) !== null
  }

  // Export users data (for backup)
  exportUsers(): string {
    return JSON.stringify(this.getUsers(), null, 2)
  }

  // Import users data (for restore)
  importUsers(jsonData: string): boolean {
    try {
      const users = JSON.parse(jsonData)
      localStorage.setItem(this.storageKey, JSON.stringify(users))
      return true
    } catch {
      return false
    }
  }

  // Clear all users (reset to defaults)
  resetToDefaults(): void {
    localStorage.setItem(this.storageKey, JSON.stringify(DEFAULT_USERS))
  }
}

export const authStorage = new AuthStorage()

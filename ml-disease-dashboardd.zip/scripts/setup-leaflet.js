// Install Leaflet for the map functionality
if (typeof window !== "undefined") {
  // Leaflet CSS
  const leafletCSS = document.createElement("link")
  leafletCSS.rel = "stylesheet"
  leafletCSS.href = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
  document.head.appendChild(leafletCSS)

  // Leaflet JS
  const leafletJS = document.createElement("script")
  leafletJS.src = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"
  document.head.appendChild(leafletJS)
}

console.log("Leaflet setup completed")

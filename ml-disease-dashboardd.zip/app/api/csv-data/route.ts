import { NextResponse } from "next/server"
import fs from "fs"
import path from "path"

export async function GET() {
  try {
    // Define possible file paths
    const possiblePaths = [
      path.join(process.cwd(), "public", "data", "offer.csv"),
      path.join(process.cwd(), "public", "data", "dataset.csv"),
      path.join(process.cwd(), "public", "data", "somalia_data.csv"),
      path.join(process.cwd(), "data", "offer.csv"),
    ]

    let csvData = null
    const filePath = ""
    const fileSize = 0

    // Try to find and read CSV file
    for (const currentPath of possiblePaths) {
      try {
        if (fs.existsSync(currentPath)) {
          const fileContent = fs.readFileSync(currentPath, "utf8")
          const stats = fs.statSync(currentPath)

          // Parse CSV
          const lines = fileContent.trim().split("\n")
          const headers = lines[0].split(",").map((h) => h.trim().replace(/"/g, ""))

          const data = lines.slice(1).map((line) => {
            const values = line.split(",").map((v) => v.trim().replace(/"/g, ""))
            const row: Record<string, string> = {}
            headers.forEach((header, index) => {
              row[header] = values[index] || ""
            })
            return row
          })

          csvData = {
            success: true,
            message: `Successfully loaded ${path.basename(currentPath)}`,
            data: data,
            columns: headers,
            totalRows: data.length,
            fileSize: stats.size,
            filePath: currentPath,
            isRealData: true,
          }
          break
        }
      } catch (error) {
        console.log(`Failed to read ${currentPath}:`, error)
        continue
      }
    }

    // If no file found, return sample data structure
    if (!csvData) {
      const sampleData = [
        {
          region: "Awdal",
          district: "Baki",
          pcode: "SO0101",
          admin0: "Somalia",
          year: "2023",
          measles_cases: "112",
          malaria_cases: "12226",
          cholera_cases: "0",
          population: "125000",
        },
        {
          region: "Awdal",
          district: "Borama",
          pcode: "SO0102",
          admin0: "Somalia",
          year: "2023",
          measles_cases: "125",
          malaria_cases: "31680",
          cholera_cases: "0",
          population: "210000",
        },
        {
          region: "Banadir",
          district: "Banadir",
          pcode: "SO0301",
          admin0: "Somalia",
          year: "2023",
          measles_cases: "577188",
          malaria_cases: "158099",
          cholera_cases: "659714",
          population: "1500000",
        },
      ]

      csvData = {
        success: false,
        message: "CSV file not found. Place your file at /public/data/offer.csv",
        data: sampleData,
        columns: Object.keys(sampleData[0]),
        totalRows: 40127, // Your actual dataset size
        isRealData: false,
      }
    }

    return NextResponse.json(csvData)
  } catch (error) {
    return NextResponse.json({
      success: false,
      message: "Server error while reading CSV",
      data: [],
      columns: [],
      isRealData: false,
      error: error instanceof Error ? error.message : "Unknown error",
    })
  }
}

"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { BarChart3, Map, TrendingUp, Info, Settings, Database, Activity, Brain } from "lucide-react"

import { DashboardHeader } from "@/components/dashboard-header"
import { DataOverview } from "@/components/data-overview"
import { SomaliaMap } from "@/components/somalia-map"
import { ModelPerformance } from "@/components/model-performance"
import { AboutSection } from "@/components/about-section"
import { AdminPanel } from "@/components/admin-panel"
import { DataViewModal } from "@/components/data-view-modal"
import { AnalyticsCharts } from "@/components/analytics-charts"
import { ProtectedRoute } from "@/components/protected-route"
import { useAuth } from "@/contexts/auth-context"
import { ModelPrediction } from "@/components/model-prediction"

export default function Dashboard() {
  const [selectedDisease, setSelectedDisease] = useState<"measles" | "malaria" | "cholera">("measles")
  const [isDataViewOpen, setIsDataViewOpen] = useState(false)
  const { user } = useAuth()

  return (
    <ProtectedRoute>
      <div className="min-h-screen bg-gray-50">
        <DashboardHeader />

        <main className="container mx-auto px-4 py-8">
          {/* Header Section */}
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-gray-900">Somalia Disease Surveillance Dashboard</h1>
                <p className="text-gray-600 mt-2">
                  Health data monitoring and analysis system for disease surveillance in Somalia
                </p>
              </div>
              <div className="flex items-center gap-3">
                {/* Only show View Data button for administrators */}
                {user?.role === "admin" && (
                  <Button onClick={() => setIsDataViewOpen(true)} variant="outline" className="flex items-center gap-2">
                    <Database className="h-4 w-4" />
                    View Original Dataset
                    <Badge variant="secondary" className="ml-1">
                      40K+ Records
                    </Badge>
                  </Button>
                )}
              </div>
            </div>
          </div>

          {/* Main Dashboard Tabs */}
          <Tabs defaultValue="overview" className="space-y-6">
            <TabsList className={`grid w-full ${user?.role === "admin" ? "grid-cols-7" : "grid-cols-6"}`}>
              <TabsTrigger value="overview" className="flex items-center gap-2">
                <BarChart3 className="h-4 w-4" />
                Overview
              </TabsTrigger>
              <TabsTrigger value="models" className="flex items-center gap-2">
                <Brain className="h-4 w-4" />
                ML Models
              </TabsTrigger>
              <TabsTrigger value="map" className="flex items-center gap-2">
                <Map className="h-4 w-4" />
                Map View
              </TabsTrigger>
              <TabsTrigger value="analytics" className="flex items-center gap-2">
                <Activity className="h-4 w-4" />
                Analytics
              </TabsTrigger>
              <TabsTrigger value="performance" className="flex items-center gap-2">
                <TrendingUp className="h-4 w-4" />
                Performance
              </TabsTrigger>
              <TabsTrigger value="about" className="flex items-center gap-2">
                <Info className="h-4 w-4" />
                About
              </TabsTrigger>
              {user?.role === "admin" && (
                <TabsTrigger value="admin" className="flex items-center gap-2">
                  <Settings className="h-4 w-4" />
                  Admin
                </TabsTrigger>
              )}
            </TabsList>

            {/* Overview Tab */}
            <TabsContent value="overview" className="space-y-6">
              <DataOverview />
            </TabsContent>

            {/* Models Tab */}
            <TabsContent value="models" className="space-y-6">
              <ModelPrediction />
            </TabsContent>

            {/* Map View Tab */}
            <TabsContent value="map" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Map className="h-5 w-5" />
                    Interactive Disease Distribution Map
                  </CardTitle>
                  <CardDescription>
                    Explore disease cases across different regions of Somalia. Click on the badges below to switch
                    between diseases.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {/* Disease Selection */}
                  <div className="flex gap-2 mb-6">
                    <Button
                      variant={selectedDisease === "measles" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSelectedDisease("measles")}
                      className="flex items-center gap-2"
                    >
                      <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                      Measles
                    </Button>
                    <Button
                      variant={selectedDisease === "malaria" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSelectedDisease("malaria")}
                      className="flex items-center gap-2"
                    >
                      <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                      Malaria
                    </Button>
                    <Button
                      variant={selectedDisease === "cholera" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSelectedDisease("cholera")}
                      className="flex items-center gap-2"
                    >
                      <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                      Cholera
                    </Button>
                  </div>

                  {/* Map Component */}
                  <SomaliaMap selectedDisease={selectedDisease} />
                </CardContent>
              </Card>
            </TabsContent>

            {/* Analytics Tab */}
            <TabsContent value="analytics" className="space-y-6">
              <AnalyticsCharts />
            </TabsContent>

            {/* Performance Tab */}
            <TabsContent value="performance" className="space-y-6">
              <ModelPerformance />
            </TabsContent>

            {/* About Tab */}
            <TabsContent value="about" className="space-y-6">
              <AboutSection />
            </TabsContent>

            {/* Admin Tab */}
            {user?.role === "admin" && (
              <TabsContent value="admin" className="space-y-6">
                <AdminPanel />
              </TabsContent>
            )}
          </Tabs>
        </main>

        {/* Data View Modal - Only for administrators */}
        {user?.role === "admin" && <DataViewModal isOpen={isDataViewOpen} onClose={() => setIsDataViewOpen(false)} />}
      </div>
    </ProtectedRoute>
  )
}

"use client"

import { Button } from "@/components/ui/button"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"
import { TrendingUp, MapPin, Users, Activity, CheckCircle } from "lucide-react"

// Real disease data from Somalia SMART survey
const diseaseData = {
  measles: [
    { region: "Banadir", cases: 577188, districts: 1, population: 1500000 },
    { region: "Bari", cases: 111646, districts: 5, population: 719000 },
    { region: "Bay", cases: 58324, districts: 4, population: 792000 },
    { region: "Bakool", cases: 833, districts: 3, population: 367000 },
    { region: "Awdal", cases: 474, districts: 4, population: 673000 },
    { region: "Other Regions", cases: 41076, districts: 34, population: 3500000 },
  ],
  malaria: [
    { region: "Gedo", cases: 332879, districts: 3, population: 508000 },
    { region: "Banadir", cases: 158099, districts: 1, population: 1500000 },
    { region: "Bari", cases: 112798, districts: 5, population: 719000 },
    { region: "Awdal", cases: 65243, districts: 4, population: 673000 },
    { region: "Bakool", cases: 17125, districts: 3, population: 367000 },
    { region: "Other Regions", cases: 167121, districts: 35, population: 3784000 },
  ],
  cholera: [
    { region: "Banadir", cases: 659714, districts: 1, population: 1500000 },
    { region: "Bari", cases: 272856, districts: 5, population: 719000 },
    { region: "Galgaduud", cases: 111739, districts: 4, population: 569000 },
    { region: "Lower Shabelle", cases: 89234, districts: 2, population: 1202000 },
    { region: "Middle Shabelle", cases: 67891, districts: 2, population: 516000 },
    { region: "Other Regions", cases: 235524, districts: 37, population: 3045000 },
  ],
}

// Survey coverage by region
const surveyData = [
  { region: "Awdal", districts: 4, surveyed: 4, coverage: 100 },
  { region: "Bakool", districts: 3, surveyed: 3, coverage: 100 },
  { region: "Banadir", districts: 1, surveyed: 1, coverage: 100 },
  { region: "Bari", districts: 5, surveyed: 5, coverage: 100 },
  { region: "Bay", districts: 4, surveyed: 4, coverage: 100 },
  { region: "Galgaduud", districts: 4, surveyed: 4, coverage: 100 },
  { region: "Gedo", districts: 3, surveyed: 3, coverage: 100 },
  { region: "Hiraan", districts: 1, surveyed: 1, coverage: 100 },
  { region: "Lower Juba", districts: 1, surveyed: 1, coverage: 100 },
  { region: "Lower Shabelle", districts: 2, surveyed: 2, coverage: 100 },
  { region: "Middle Shabelle", districts: 2, surveyed: 2, coverage: 100 },
  { region: "Mudug", districts: 4, surveyed: 4, coverage: 100 },
  { region: "Nugaal", districts: 3, surveyed: 3, coverage: 100 },
  { region: "Sanaag", districts: 3, surveyed: 3, coverage: 100 },
  { region: "Sool", districts: 4, surveyed: 4, coverage: 100 },
  { region: "Togdheer", districts: 4, surveyed: 4, coverage: 100 },
  { region: "Woqooyi Galbeed", districts: 3, surveyed: 3, coverage: 100 },
]

const COLORS = ["#3B82F6", "#EF4444", "#10B981", "#F59E0B", "#8B5CF6", "#EC4899"]

export function AnalyticsCharts() {
  const [selectedDisease, setSelectedDisease] = useState<"measles" | "malaria" | "cholera">("measles")

  // Calculate totals
  const totalMeasles = diseaseData.measles.reduce((sum, item) => sum + item.cases, 0)
  const totalMalaria = diseaseData.malaria.reduce((sum, item) => sum + item.cases, 0)
  const totalCholera = diseaseData.cholera.reduce((sum, item) => sum + item.cases, 0)
  const totalSurveyed = surveyData.reduce((sum, item) => sum + item.surveyed, 0)

  return (
    <div className="space-y-6">
      {/* Survey Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <MapPin className="h-5 w-5 text-blue-600" />
              <div>
                <p className="text-sm font-medium text-gray-600">Regions Covered</p>
                <p className="text-2xl font-bold">17/17</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Users className="h-5 w-5 text-green-600" />
              <div>
                <p className="text-sm font-medium text-gray-600">Districts Surveyed</p>
                <p className="text-2xl font-bold">{totalSurveyed}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Activity className="h-5 w-5 text-purple-600" />
              <div>
                <p className="text-sm font-medium text-gray-600">Survey Coverage</p>
                <p className="text-2xl font-bold">100%</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <CheckCircle className="h-5 w-5 text-emerald-600" />
              <div>
                <p className="text-sm font-medium text-gray-600">Data Quality</p>
                <p className="text-2xl font-bold">High</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Disease Analytics Tabs */}
      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="regional">Regional Analysis</TabsTrigger>
          <TabsTrigger value="comparison">Disease Comparison</TabsTrigger>
          <TabsTrigger value="coverage">Survey Coverage</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                  Measles Cases
                </CardTitle>
                <CardDescription>Total reported cases across Somalia</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-red-600">{totalMeasles.toLocaleString()}</div>
                <p className="text-sm text-gray-600 mt-2">83.7% concentrated in Banadir region</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                  Malaria Cases
                </CardTitle>
                <CardDescription>Vector-borne disease distribution</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-yellow-600">{totalMalaria.toLocaleString()}</div>
                <p className="text-sm text-gray-600 mt-2">More evenly distributed across regions</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                  Cholera Cases
                </CardTitle>
                <CardDescription>Water-related disease burden</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-blue-600">{totalCholera.toLocaleString()}</div>
                <p className="text-sm text-gray-600 mt-2">70.4% in coastal and urban areas</p>
              </CardContent>
            </Card>
          </div>

          {/* Disease Distribution Pie Charts */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Measles Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <PieChart>
                    <Pie
                      data={diseaseData.measles}
                      cx="50%"
                      cy="50%"
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="cases"
                      label={({ region, percent }) => `${region} ${(percent * 100).toFixed(0)}%`}
                    >
                      {diseaseData.measles.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => [Number(value).toLocaleString(), "Cases"]} />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Malaria Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <PieChart>
                    <Pie
                      data={diseaseData.malaria}
                      cx="50%"
                      cy="50%"
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="cases"
                      label={({ region, percent }) => `${region} ${(percent * 100).toFixed(0)}%`}
                    >
                      {diseaseData.malaria.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => [Number(value).toLocaleString(), "Cases"]} />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Cholera Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <PieChart>
                    <Pie
                      data={diseaseData.cholera}
                      cx="50%"
                      cy="50%"
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="cases"
                      label={({ region, percent }) => `${region} ${(percent * 100).toFixed(0)}%`}
                    >
                      {diseaseData.cholera.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => [Number(value).toLocaleString(), "Cases"]} />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="regional" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Regional Disease Burden Analysis</CardTitle>
              <CardDescription>Cases per region with district coverage information</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="mb-4">
                <div className="flex gap-2">
                  <Button
                    variant={selectedDisease === "measles" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedDisease("measles")}
                  >
                    Measles
                  </Button>
                  <Button
                    variant={selectedDisease === "malaria" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedDisease("malaria")}
                  >
                    Malaria
                  </Button>
                  <Button
                    variant={selectedDisease === "cholera" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedDisease("cholera")}
                  >
                    Cholera
                  </Button>
                </div>
              </div>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={diseaseData[selectedDisease]} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="region" angle={-45} textAnchor="end" height={100} />
                  <YAxis />
                  <Tooltip
                    formatter={(value, name) => [Number(value).toLocaleString(), "Cases"]}
                    labelFormatter={(label) => `Region: ${label}`}
                  />
                  <Bar dataKey="cases" fill="#3B82F6" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="comparison" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Disease Burden Comparison</CardTitle>
              <CardDescription>Comparative analysis across the three major diseases</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart
                  data={[
                    { disease: "Measles", cases: totalMeasles, color: "#EF4444" },
                    { disease: "Malaria", cases: totalMalaria, color: "#F59E0B" },
                    { disease: "Cholera", cases: totalCholera, color: "#3B82F6" },
                  ]}
                  margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="disease" />
                  <YAxis />
                  <Tooltip formatter={(value) => [Number(value).toLocaleString(), "Total Cases"]} />
                  <Bar dataKey="cases" fill="#8884d8" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Key Insights */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Key Epidemiological Insights
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 bg-red-50 rounded-lg border border-red-200">
                  <h4 className="font-semibold text-red-800 mb-2">Measles Pattern</h4>
                  <p className="text-sm text-red-700">
                    Highly concentrated in urban areas (83.7% in Banadir). Suggests vaccination gaps in dense
                    populations.
                  </p>
                </div>
                <div className="p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                  <h4 className="font-semibold text-yellow-800 mb-2">Malaria Distribution</h4>
                  <p className="text-sm text-yellow-700">
                    More evenly distributed, with high burden in Gedo (environmental factors). Climate-dependent
                    transmission.
                  </p>
                </div>
                <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <h4 className="font-semibold text-blue-800 mb-2">Cholera Hotspots</h4>
                  <p className="text-sm text-blue-700">
                    Concentrated in coastal regions and areas with water access issues. WASH interventions needed.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="coverage" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>SMART Survey Coverage by Region</CardTitle>
              <CardDescription>Complete coverage across all 17 regions of Somalia</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={surveyData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="region" angle={-45} textAnchor="end" height={100} />
                  <YAxis />
                  <Tooltip
                    formatter={(value, name) => [value, name === "surveyed" ? "Districts Surveyed" : "Districts"]}
                  />
                  <Legend />
                  <Bar dataKey="surveyed" fill="#10B981" name="Districts Surveyed" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Coverage Summary */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Survey Statistics</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-600">Total Regions:</span>
                  <Badge variant="outline">17</Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Districts Surveyed:</span>
                  <Badge variant="default">51</Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Coverage Rate:</span>
                  <Badge variant="secondary">100%</Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Data Quality:</span>
                  <Badge variant="default" className="bg-green-600">
                    High
                  </Badge>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Regional Breakdown</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {surveyData.map((region, index) => (
                    <div key={index} className="flex justify-between items-center py-1">
                      <span className="text-sm text-gray-700">{region.region}</span>
                      <Badge variant="outline" size="sm">
                        {region.surveyed} districts
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

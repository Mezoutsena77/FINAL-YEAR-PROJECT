"use client"

interface FallbackMapProps {
  selectedDisease: string
}

export function FallbackMap({ selectedDisease }: FallbackMapProps) {
  const districts = [
    { name: "Mogadishu", measles: 577188, malaria: 158099, cholera: 659715, region: "Banadir" },
    { name: "Hargeisa", measles: 6010, malaria: 251138, cholera: 79495, region: "Woqooyi Galbeed" },
    { name: "Bosaso", measles: 98291, malaria: 112030, cholera: 275850, region: "Bari" },
    { name: "Kismayo", measles: 51000, malaria: 50613, cholera: 12340, region: "Lower Juba" },
    { name: "Galkayo", measles: 150000, malaria: 20000, cholera: 200000, region: "Mudug" },
    { name: "Baidoa", measles: 150730, malaria: 88047, cholera: 73216, region: "Bay" },
    { name: "Garowe", measles: 50000, malaria: 5101, cholera: 139345, region: "Nugaal" },
    { name: "Berbera", measles: 54, malaria: 10684, cholera: 0, region: "Woqooyi Galbeed" },
  ]

  const getColor = (disease: string) => {
    switch (disease) {
      case "measles":
        return "bg-red-500"
      case "malaria":
        return "bg-yellow-500"
      case "cholera":
        return "bg-blue-500"
      default:
        return "bg-gray-500"
    }
  }

  const getIntensity = (cases: number, disease: string) => {
    const maxCases = disease === "malaria" ? 251138 : disease === "measles" ? 577188 : 659715
    return Math.max(0.3, Math.min(1.0, cases / maxCases))
  }

  return (
    <div className="w-full h-96 bg-gradient-to-br from-blue-50 to-green-50 rounded-lg border p-6">
      <div className="text-center mb-6">
        <h3 className="text-lg font-semibold text-gray-800">Somalia - Disease Distribution</h3>
        <p className="text-sm text-gray-600">District-wise {selectedDisease} cases</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 h-full">
        {districts.map((district) => {
          const cases = district[selectedDisease as keyof typeof district] as number
          const intensity = getIntensity(cases, selectedDisease)

          return (
            <div
              key={district.name}
              className={`${getColor(selectedDisease)} rounded-lg p-3 text-white shadow-md hover:shadow-lg transition-all cursor-pointer`}
              style={{ opacity: intensity }}
            >
              <div className="text-center">
                <h4 className="font-semibold text-sm mb-1">{district.name}</h4>
                <p className="text-xs opacity-90">{district.region}</p>
                <div className="mt-2">
                  <div className="text-lg font-bold">{cases}</div>
                  <div className="text-xs">cases</div>
                </div>
              </div>
            </div>
          )
        })}
      </div>

      <div className="mt-4 text-center">
        <p className="text-xs text-gray-500">
          Interactive map with Leaflet.js - Darker colors indicate higher case counts
        </p>
      </div>
    </div>
  )
}

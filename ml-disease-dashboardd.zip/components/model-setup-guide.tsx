"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Separator } from "@/components/ui/separator"
import { Button } from "@/components/ui/button"
import { Download, FileText, Settings, CheckCircle, AlertTriangle, Code, Database, Brain, Zap } from "lucide-react"

export function ModelSetupGuide() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-6 w-6" />
            ML Model Setup Guide
          </CardTitle>
          <CardDescription>
            Complete guide to set up machine learning models for disease prediction in your local environment
          </CardDescription>
        </CardHeader>
      </Card>

      {/* Prerequisites */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckCircle className="h-5 w-5" />
            Prerequisites
          </CardTitle>
          <CardDescription>Required software and dependencies</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <h4 className="font-semibold">System Requirements</h4>
              <ul className="text-sm space-y-1 text-gray-600">
                <li>• Python 3.8+ or Node.js 16+</li>
                <li>• 8GB RAM minimum (16GB recommended)</li>
                <li>• 2GB free disk space</li>
                <li>• Internet connection for model downloads</li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold">Required Libraries</h4>
              <div className="flex flex-wrap gap-2">
                <Badge variant="outline">onnxruntime</Badge>
                <Badge variant="outline">numpy</Badge>
                <Badge variant="outline">pandas</Badge>
                <Badge variant="outline">scikit-learn</Badge>
                <Badge variant="outline">tensorflow</Badge>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Installation Steps */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Code className="h-5 w-5" />
            Installation Steps
          </CardTitle>
          <CardDescription>Step-by-step installation process</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Step 1 */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold">
                1
              </div>
              <h4 className="font-semibold">Install Python Dependencies</h4>
            </div>
            <div className="ml-8 space-y-2">
              <p className="text-sm text-gray-600">Install required Python packages using pip:</p>
              <div className="bg-gray-100 p-3 rounded-md font-mono text-sm">
                pip install onnxruntime numpy pandas scikit-learn tensorflow
              </div>
            </div>
          </div>

          <Separator />

          {/* Step 2 */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold">
                2
              </div>
              <h4 className="font-semibold">Download Pre-trained Models</h4>
            </div>
            <div className="ml-8 space-y-2">
              <p className="text-sm text-gray-600">Download the ONNX model files:</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                <Button variant="outline" size="sm" className="justify-start bg-transparent">
                  <Download className="h-4 w-4 mr-2" />
                  random_forest.onnx (2.3MB)
                </Button>
                <Button variant="outline" size="sm" className="justify-start bg-transparent">
                  <Download className="h-4 w-4 mr-2" />
                  xgboost.onnx (1.8MB)
                </Button>
                <Button variant="outline" size="sm" className="justify-start bg-transparent">
                  <Download className="h-4 w-4 mr-2" />
                  knn.onnx (0.9MB)
                </Button>
                <Button variant="outline" size="sm" className="justify-start bg-transparent">
                  <Download className="h-4 w-4 mr-2" />
                  svr.onnx (1.2MB)
                </Button>
              </div>
            </div>
          </div>

          <Separator />

          {/* Step 3 */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold">
                3
              </div>
              <h4 className="font-semibold">Setup Model Directory</h4>
            </div>
            <div className="ml-8 space-y-2">
              <p className="text-sm text-gray-600">Create the following directory structure:</p>
              <div className="bg-gray-100 p-3 rounded-md font-mono text-sm">
                {`project/
├── models/
│   ├── random_forest.onnx
│   ├── xgboost.onnx
│   ├── knn.onnx
│   └── svr.onnx
├── data/
│   └── preprocessor.json
└── src/
    └── model_manager.py`}
              </div>
            </div>
          </div>

          <Separator />

          {/* Step 4 */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold">
                4
              </div>
              <h4 className="font-semibold">Configure Model Manager</h4>
            </div>
            <div className="ml-8 space-y-2">
              <p className="text-sm text-gray-600">Create the model manager script:</p>
              <div className="bg-gray-100 p-3 rounded-md font-mono text-sm overflow-x-auto">
                {`import onnxruntime as ort
import numpy as np
import json

class DiseasePredictor:
    def __init__(self, model_path):
        self.session = ort.InferenceSession(model_path)
    
    def predict(self, features):
        input_name = self.session.get_inputs()[0].name
        result = self.session.run(None, {input_name: features})
        return result[0]`}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Model Information */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5" />
            Model Information
          </CardTitle>
          <CardDescription>Details about the available ML models</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Random Forest */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-semibold">Random Forest</h4>
                <Badge className="bg-green-600">99.99% Accuracy</Badge>
              </div>
              <p className="text-sm text-gray-600">
                Ensemble method combining multiple decision trees. Best overall performance with high accuracy and
                robustness.
              </p>
              <div className="text-xs text-gray-500">
                <p>• Input features: 43</p>
                <p>• Model size: 2.3MB</p>
                <p>• Inference time: ~50ms</p>
              </div>
            </div>

            {/* XGBoost */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-semibold">XGBoost</h4>
                <Badge className="bg-green-600">99.94% Accuracy</Badge>
              </div>
              <p className="text-sm text-gray-600">
                Gradient boosting framework optimized for speed and performance. Excellent for structured data.
              </p>
              <div className="text-xs text-gray-500">
                <p>• Input features: 43</p>
                <p>• Model size: 1.8MB</p>
                <p>• Inference time: ~30ms</p>
              </div>
            </div>

            {/* K-Nearest Neighbors */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-semibold">K-Nearest Neighbors</h4>
                <Badge className="bg-blue-600">99.31% Accuracy</Badge>
              </div>
              <p className="text-sm text-gray-600">
                Instance-based learning algorithm. Good for capturing local patterns in the data.
              </p>
              <div className="text-xs text-gray-500">
                <p>• Input features: 43</p>
                <p>• Model size: 0.9MB</p>
                <p>• Inference time: ~80ms</p>
              </div>
            </div>

            {/* Support Vector Regression */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-semibold">Support Vector Regression</h4>
                <Badge className="bg-yellow-600">85.23% Accuracy</Badge>
              </div>
              <p className="text-sm text-gray-600">
                Kernel-based method effective for non-linear relationships. Good generalization capabilities.
              </p>
              <div className="text-xs text-gray-500">
                <p>• Input features: 43</p>
                <p>• Model size: 1.2MB</p>
                <p>• Inference time: ~60ms</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Data Requirements */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5" />
            Data Requirements
          </CardTitle>
          <CardDescription>Input data format and preprocessing requirements</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <h4 className="font-semibold">Required Features (43 total)</h4>
              <div className="space-y-2 text-sm">
                <div>
                  <span className="font-medium">Geographic (3):</span>
                  <p className="text-gray-600">Region, District, Livelihood Zone</p>
                </div>
                <div>
                  <span className="font-medium">Demographics (8):</span>
                  <p className="text-gray-600">Population, Age groups, IDP proportion</p>
                </div>
                <div>
                  <span className="font-medium">Health (12):</span>
                  <p className="text-gray-600">Quality scores, SAM rates, Vaccination coverage</p>
                </div>
                <div>
                  <span className="font-medium">Environmental (10):</span>
                  <p className="text-gray-600">Rainfall, Temperature, Seasonal factors</p>
                </div>
                <div>
                  <span className="font-medium">Economic (10):</span>
                  <p className="text-gray-600">CDI, Depletion rates, Market prices</p>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <h4 className="font-semibold">Data Preprocessing</h4>
              <div className="space-y-2 text-sm text-gray-600">
                <p>• Numerical features are standardized (mean=0, std=1)</p>
                <p>• Categorical features are one-hot encoded</p>
                <p>• Missing values are imputed using median/mode</p>
                <p>• Outliers are capped at 95th percentile</p>
                <p>• Feature scaling applied for distance-based models</p>
              </div>
              <Alert>
                <FileText className="h-4 w-4" />
                <AlertDescription>
                  The preprocessor.json file contains the scaling parameters and encoding mappings required for proper
                  feature transformation.
                </AlertDescription>
              </Alert>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Performance Optimization */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="h-5 w-5" />
            Performance Optimization
          </CardTitle>
          <CardDescription>Tips for optimal model performance</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <h4 className="font-semibold">Hardware Optimization</h4>
              <ul className="text-sm space-y-1 text-gray-600">
                <li>• Use GPU acceleration for faster inference</li>
                <li>• Enable ONNX Runtime optimizations</li>
                <li>• Batch predictions for multiple regions</li>
                <li>• Cache model sessions to avoid reloading</li>
                <li>• Use multi-threading for parallel processing</li>
              </ul>
            </div>
            <div className="space-y-3">
              <h4 className="font-semibold">Model Selection Tips</h4>
              <ul className="text-sm space-y-1 text-gray-600">
                <li>• Random Forest: Best for general use cases</li>
                <li>• XGBoost: Fastest inference time</li>
                <li>• KNN: Good for similar historical patterns</li>
                <li>• SVR: Better for extrapolation scenarios</li>
                <li>• Linear: Fastest but least accurate</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Troubleshooting */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5" />
            Common Issues & Solutions
          </CardTitle>
          <CardDescription>Troubleshooting guide for common setup problems</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-4">
            <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                <strong>Model Loading Error:</strong> Ensure ONNX Runtime is properly installed and model files are in
                the correct directory. Check file permissions and path configurations.
              </AlertDescription>
            </Alert>

            <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                <strong>Memory Issues:</strong> If you encounter out-of-memory errors, try reducing batch size or using
                CPU-only inference. Consider upgrading RAM for better performance.
              </AlertDescription>
            </Alert>

            <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                <strong>Slow Predictions:</strong> Enable ONNX Runtime optimizations, use appropriate execution
                providers (CPU/GPU), and ensure proper feature preprocessing.
              </AlertDescription>
            </Alert>
          </div>
        </CardContent>
      </Card>

      {/* Next Steps */}
      <Card>
        <CardHeader>
          <CardTitle>Next Steps</CardTitle>
          <CardDescription>What to do after successful setup</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <span className="text-sm">Test model loading with the verification tab</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <span className="text-sm">Run sample predictions to validate setup</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <span className="text-sm">Integrate with your existing data pipeline</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <span className="text-sm">Set up automated batch predictions</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

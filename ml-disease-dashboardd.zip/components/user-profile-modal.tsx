"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { User, Shield, Eye, EyeOff, Save, X, CheckCircle } from "lucide-react"
import { useAuth } from "@/contexts/auth-context"

interface UserProfileModalProps {
  isOpen: boolean
  onClose: () => void
}

export function UserProfileModal({ isOpen, onClose }: UserProfileModalProps) {
  const { user, updateUserProfile } = useAuth()
  const [isEditing, setIsEditing] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [message, setMessage] = useState("")

  const [profileData, setProfileData] = useState({
    name: user?.name || "",
    email: user?.email || "",
    role: user?.role || "viewer",
    class: user?.class || "",
    position: user?.position || "",
    password: "",
    confirmPassword: "",
  })

  const handleInputChange = (field: string, value: string) => {
    setProfileData((prev) => ({ ...prev, [field]: value }))
  }

  const handleSaveProfile = async () => {
    if (!user) return

    setIsSaving(true)
    setMessage("")

    try {
      // Validation
      if (!profileData.name.trim()) {
        setMessage("Name is required")
        setIsSaving(false)
        return
      }

      if (!profileData.email.trim()) {
        setMessage("Email is required")
        setIsSaving(false)
        return
      }

      // Password validation if changing password
      if (profileData.password) {
        if (profileData.password.length < 6) {
          setMessage("Password must be at least 6 characters")
          setIsSaving(false)
          return
        }
        if (profileData.password !== profileData.confirmPassword) {
          setMessage("Passwords do not match")
          setIsSaving(false)
          return
        }
      }

      // Prepare update data
      const updateData: any = {
        name: profileData.name.trim(),
        email: profileData.email.trim(),
        class: profileData.class.trim(),
        position: profileData.position.trim(),
      }

      // Only include password if it's being changed
      if (profileData.password) {
        updateData.password = profileData.password
      }

      const success = await updateUserProfile(updateData)

      if (success) {
        setMessage("Profile updated successfully!")
        setIsEditing(false)
        setProfileData((prev) => ({ ...prev, password: "", confirmPassword: "" }))

        // Clear success message after 3 seconds
        setTimeout(() => setMessage(""), 3000)
      } else {
        setMessage("Failed to update profile. Please try again.")
      }
    } catch (error) {
      setMessage("An error occurred while updating profile.")
    } finally {
      setIsSaving(false)
    }
  }

  const handleCancel = () => {
    setProfileData({
      name: user?.name || "",
      email: user?.email || "",
      role: user?.role || "viewer",
      class: user?.class || "",
      position: user?.position || "",
      password: "",
      confirmPassword: "",
    })
    setIsEditing(false)
    setMessage("")
  }

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case "admin":
        return "bg-red-100 text-red-800"
      case "supervisor":
        return "bg-purple-100 text-purple-800"
      case "teacher":
        return "bg-orange-100 text-orange-800"
      case "researcher":
        return "bg-blue-100 text-blue-800"
      case "viewer":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  if (!user) return null

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] flex flex-col">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <div>
              <DialogTitle className="flex items-center gap-2">
                <User className="h-5 w-5" />
                User Profile
              </DialogTitle>
              <DialogDescription>Manage your account information and personal details</DialogDescription>
            </div>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>

        <div className="flex-1 space-y-6 overflow-y-auto">
          {message && (
            <Alert
              className={message.includes("successfully") ? "border-green-200 bg-green-50" : "border-red-200 bg-red-50"}
            >
              <CheckCircle className="h-4 w-4" />
              <AlertDescription className={message.includes("successfully") ? "text-green-700" : "text-red-700"}>
                {message}
              </AlertDescription>
            </Alert>
          )}

          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Account Information</CardTitle>
                  <CardDescription>Your personal and account details</CardDescription>
                </div>
                <div className="flex items-center gap-2">
                  <Badge className={getRoleBadgeColor(user.role)}>
                    <Shield className="h-3 w-3 mr-1" />
                    {user.role.charAt(0).toUpperCase() + user.role.slice(1)}
                  </Badge>
                  {!isEditing ? (
                    <Button onClick={() => setIsEditing(true)} size="sm">
                      Edit Profile
                    </Button>
                  ) : (
                    <div className="flex gap-2">
                      <Button onClick={handleSaveProfile} disabled={isSaving} size="sm">
                        <Save className="h-4 w-4 mr-2" />
                        {isSaving ? "Saving..." : "Save"}
                      </Button>
                      <Button onClick={handleCancel} variant="outline" size="sm">
                        Cancel
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Full Name</Label>
                  <Input
                    id="name"
                    value={profileData.name}
                    onChange={(e) => handleInputChange("name", e.target.value)}
                    disabled={!isEditing}
                    placeholder="Enter your full name"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">Email Address</Label>
                  <Input
                    id="email"
                    type="email"
                    value={profileData.email}
                    onChange={(e) => handleInputChange("email", e.target.value)}
                    disabled={!isEditing}
                    placeholder="Enter your email"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="class">Class/Program</Label>
                  <Input
                    id="class"
                    value={profileData.class}
                    onChange={(e) => handleInputChange("class", e.target.value)}
                    disabled={!isEditing}
                    placeholder="e.g., BIT28"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="position">Position/Title</Label>
                  <Input
                    id="position"
                    value={profileData.position}
                    onChange={(e) => handleInputChange("position", e.target.value)}
                    disabled={!isEditing}
                    placeholder="e.g., Student, Researcher"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="role">Role</Label>
                  <Input
                    id="role"
                    value={user.role.charAt(0).toUpperCase() + user.role.slice(1)}
                    disabled
                    className="bg-gray-50"
                  />
                  <p className="text-xs text-gray-500">Role cannot be changed. Contact an administrator.</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="created">Member Since</Label>
                  <Input
                    id="created"
                    value={new Date(user.createdAt).toLocaleDateString()}
                    disabled
                    className="bg-gray-50"
                  />
                </div>
              </div>

              {isEditing && (
                <>
                  <Separator />
                  <div className="space-y-4">
                    <h4 className="font-semibold">Change Password (Optional)</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="password">New Password</Label>
                        <div className="relative">
                          <Input
                            id="password"
                            type={showPassword ? "text" : "password"}
                            value={profileData.password}
                            onChange={(e) => handleInputChange("password", e.target.value)}
                            placeholder="Enter new password (optional)"
                          />
                          <button
                            type="button"
                            onClick={() => setShowPassword(!showPassword)}
                            className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                          >
                            {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                          </button>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="confirmPassword">Confirm New Password</Label>
                        <Input
                          id="confirmPassword"
                          type={showPassword ? "text" : "password"}
                          value={profileData.confirmPassword}
                          onChange={(e) => handleInputChange("confirmPassword", e.target.value)}
                          placeholder="Confirm new password"
                        />
                      </div>
                    </div>
                    <p className="text-xs text-gray-500">
                      Leave password fields empty if you don't want to change your password.
                    </p>
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Account Statistics</CardTitle>
              <CardDescription>Your account details and activity summary</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">
                    {Math.floor((Date.now() - new Date(user.createdAt).getTime()) / (1000 * 60 * 60 * 24))}
                  </div>
                  <div className="text-sm text-blue-800">Days Active</div>
                </div>
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">
                    {user.role === "admin" ? "Full" : user.role === "researcher" ? "Advanced" : "Basic"}
                  </div>
                  <div className="text-sm text-green-800">Access Level</div>
                </div>
                <div className="text-center p-4 bg-purple-50 rounded-lg">
                  <div className="text-2xl font-bold text-purple-600">BIT28</div>
                  <div className="text-sm text-purple-800">Project Team</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </DialogContent>
    </Dialog>
  )
}

"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  ResponsiveContainer,
  LineChart,
  Line,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
} from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { TrendingUp, Award, Target, BarChart3, Info } from "lucide-react"

// Your actual model performance metrics
const modelMetrics = [
  {
    model: "Random Forest",
    rmse_mean: 0.159944,
    rmse_std: 0.100122,
    r2_mean: 0.999994,
    r2_std: 0.000004,
    rank: 1,
    color: "#22c55e",
    description: "Best performing model with highest accuracy",
  },
  {
    model: "XGBoost",
    rmse_mean: 1.051563,
    rmse_std: 2.019056,
    r2_mean: 0.999375,
    r2_std: 0.001248,
    rank: 2,
    color: "#3b82f6",
    description: "Excellent gradient boosting performance",
  },
  {
    model: "KNN",
    rmse_mean: 9.493005,
    rmse_std: 2.396232,
    r2_mean: 0.993128,
    r2_std: 0.002522,
    rank: 3,
    color: "#8b5cf6",
    description: "Good pattern recognition capabilities",
  },
  {
    model: "SVR",
    rmse_mean: 47.714571,
    rmse_std: 2.556557,
    r2_mean: 0.852298,
    r2_std: 0.011508,
    rank: 4,
    color: "#f59e0b",
    description: "Solid regression performance",
  },
  {
    model: "Linear",
    rmse_mean: 89.549674,
    rmse_std: 1.044562,
    r2_mean: 0.430743,
    r2_std: 0.010964,
    rank: 5,
    color: "#ef4444",
    description: "Baseline linear model",
  },
]

// Data for radar chart
const radarData = modelMetrics.map((model) => ({
  model: model.model,
  accuracy: model.r2_mean * 100,
  stability: (1 - model.r2_std) * 100,
  precision: (1 / (model.rmse_mean + 1)) * 100,
  consistency: (1 - model.rmse_std / 100) * 100,
}))

export function ModelPerformance() {
  const bestModel = modelMetrics[0] // Random Forest
  const worstModel = modelMetrics[modelMetrics.length - 1] // Linear

  return (
    <div className="space-y-6">
      {/* Performance Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-l-4 border-l-green-500">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Award className="h-4 w-4 text-green-500" />
              Best Model
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{bestModel.model}</div>
            <p className="text-xs text-muted-foreground">R² = {(bestModel.r2_mean * 100).toFixed(4)}%</p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-blue-500">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Target className="h-4 w-4 text-blue-500" />
              Avg R² Score
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">
              {((modelMetrics.reduce((sum, m) => sum + m.r2_mean, 0) / modelMetrics.length) * 100).toFixed(2)}%
            </div>
            <p className="text-xs text-muted-foreground">Across all models</p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-purple-500">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-purple-500" />
              Best RMSE
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">{bestModel.rmse_mean.toFixed(3)}</div>
            <p className="text-xs text-muted-foreground">Lowest error rate</p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-orange-500">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <BarChart3 className="h-4 w-4 text-orange-500" />
              Models Tested
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{modelMetrics.length}</div>
            <p className="text-xs text-muted-foreground">ML algorithms</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="rankings" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="rankings">Model Rankings</TabsTrigger>
          <TabsTrigger value="metrics">Detailed Metrics</TabsTrigger>
          <TabsTrigger value="comparison">Visual Comparison</TabsTrigger>
          <TabsTrigger value="analysis">Performance Analysis</TabsTrigger>
        </TabsList>

        <TabsContent value="rankings" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Award className="h-5 w-5" />
                Model Performance Rankings
              </CardTitle>
              <CardDescription>
                Models ranked by R² score (coefficient of determination) - higher is better
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {modelMetrics.map((model, index) => (
                  <div key={model.model} className="flex items-center space-x-4 p-4 border rounded-lg">
                    <div
                      className="flex items-center justify-center w-8 h-8 rounded-full"
                      style={{ backgroundColor: model.color }}
                    >
                      <span className="text-white font-bold text-sm">#{model.rank}</span>
                    </div>

                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="font-semibold text-lg">{model.model}</h3>
                        <Badge className="text-white" style={{ backgroundColor: model.color }}>
                          R² = {(model.r2_mean * 100).toFixed(4)}%
                        </Badge>
                      </div>

                      <p className="text-sm text-gray-600 mb-2">{model.description}</p>

                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="text-gray-500">RMSE:</span>
                          <span className="ml-2 font-medium">
                            {model.rmse_mean.toFixed(3)} ± {model.rmse_std.toFixed(3)}
                          </span>
                        </div>
                        <div>
                          <span className="text-gray-500">R² Std:</span>
                          <span className="ml-2 font-medium">{model.r2_std.toFixed(6)}</span>
                        </div>
                      </div>

                      <div className="mt-2">
                        <Progress
                          value={model.r2_mean * 100}
                          className="h-2"
                          style={{
                            background: `linear-gradient(to right, ${model.color}20 0%, ${model.color} ${model.r2_mean * 100}%, #f1f5f9 ${model.r2_mean * 100}%)`,
                          }}
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="metrics" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>R² Score Comparison</CardTitle>
                <CardDescription>Coefficient of determination (higher = better)</CardDescription>
              </CardHeader>
              <CardContent>
                <ChartContainer
                  config={{
                    r2_mean: { label: "R² Score", color: "#3b82f6" },
                  }}
                  className="h-80"
                >
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={modelMetrics} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="model" angle={-45} textAnchor="end" height={80} />
                      <YAxis domain={[0, 1]} />
                      <ChartTooltip content={<ChartTooltipContent />} />
                      <Bar dataKey="r2_mean" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </ChartContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>RMSE Comparison</CardTitle>
                <CardDescription>Root Mean Square Error (lower = better)</CardDescription>
              </CardHeader>
              <CardContent>
                <ChartContainer
                  config={{
                    rmse_mean: { label: "RMSE", color: "#ef4444" },
                  }}
                  className="h-80"
                >
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={modelMetrics} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="model" angle={-45} textAnchor="end" height={80} />
                      <YAxis />
                      <ChartTooltip content={<ChartTooltipContent />} />
                      <Bar dataKey="rmse_mean" fill="#ef4444" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </ChartContainer>
              </CardContent>
            </Card>
          </div>

          {/* Detailed Metrics Table */}
          <Card>
            <CardHeader>
              <CardTitle>Complete Performance Metrics</CardTitle>
              <CardDescription>Detailed statistical performance of all models</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left p-3 font-semibold">Rank</th>
                      <th className="text-left p-3 font-semibold">Model</th>
                      <th className="text-right p-3 font-semibold">RMSE Mean</th>
                      <th className="text-right p-3 font-semibold">RMSE Std</th>
                      <th className="text-right p-3 font-semibold">R² Mean</th>
                      <th className="text-right p-3 font-semibold">R² Std</th>
                    </tr>
                  </thead>
                  <tbody>
                    {modelMetrics.map((model) => (
                      <tr key={model.model} className="border-b hover:bg-gray-50">
                        <td className="p-3">
                          <Badge style={{ backgroundColor: model.color }} className="text-white">
                            #{model.rank}
                          </Badge>
                        </td>
                        <td className="p-3 font-medium">{model.model}</td>
                        <td className="p-3 text-right font-mono">{model.rmse_mean.toFixed(6)}</td>
                        <td className="p-3 text-right font-mono">{model.rmse_std.toFixed(6)}</td>
                        <td className="p-3 text-right font-mono">{model.r2_mean.toFixed(6)}</td>
                        <td className="p-3 text-right font-mono">{model.r2_std.toFixed(6)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="comparison" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Performance Radar Chart</CardTitle>
                <CardDescription>Multi-dimensional model comparison</CardDescription>
              </CardHeader>
              <CardContent>
                <ChartContainer
                  config={{
                    accuracy: { label: "Accuracy", color: "#22c55e" },
                    stability: { label: "Stability", color: "#3b82f6" },
                    precision: { label: "Precision", color: "#8b5cf6" },
                    consistency: { label: "Consistency", color: "#f59e0b" },
                  }}
                  className="h-80"
                >
                  <ResponsiveContainer width="100%" height="100%">
                    <RadarChart data={radarData.slice(0, 3)}>
                      <PolarGrid />
                      <PolarAngleAxis dataKey="model" />
                      <PolarRadiusAxis domain={[0, 100]} />
                      <Radar
                        name="Random Forest"
                        dataKey="accuracy"
                        stroke="#22c55e"
                        fill="#22c55e"
                        fillOpacity={0.1}
                      />
                      <Radar name="XGBoost" dataKey="accuracy" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.1} />
                      <Radar name="KNN" dataKey="accuracy" stroke="#8b5cf6" fill="#8b5cf6" fillOpacity={0.1} />
                    </RadarChart>
                  </ResponsiveContainer>
                </ChartContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Error vs Accuracy Trade-off</CardTitle>
                <CardDescription>RMSE vs R² relationship</CardDescription>
              </CardHeader>
              <CardContent>
                <ChartContainer
                  config={{
                    r2_mean: { label: "R² Score", color: "#3b82f6" },
                  }}
                  className="h-80"
                >
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={modelMetrics.sort((a, b) => a.rmse_mean - b.rmse_mean)}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="rmse_mean" label={{ value: "RMSE", position: "insideBottom", offset: -5 }} />
                      <YAxis label={{ value: "R² Score", angle: -90, position: "insideLeft" }} />
                      <ChartTooltip content={<ChartTooltipContent />} />
                      <Line type="monotone" dataKey="r2_mean" stroke="#3b82f6" strokeWidth={3} dot={{ r: 6 }} />
                    </LineChart>
                  </ResponsiveContainer>
                </ChartContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="analysis" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-green-500" />
                  Key Findings
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Alert>
                  <Info className="h-4 w-4" />
                  <AlertDescription>
                    <strong>Random Forest</strong> achieved the highest performance with R² = 99.9994%, demonstrating
                    exceptional accuracy for disease case estimation.
                  </AlertDescription>
                </Alert>

                <div className="space-y-3">
                  <div className="p-3 bg-green-50 rounded-lg">
                    <h4 className="font-semibold text-green-800">Best Performers</h4>
                    <ul className="text-sm text-green-700 mt-1 space-y-1">
                      <li>• Random Forest: R² = 99.9994% (RMSE: 0.16)</li>
                      <li>• XGBoost: R² = 99.9375% (RMSE: 1.05)</li>
                      <li>• KNN: R² = 99.3128% (RMSE: 9.49)</li>
                    </ul>
                  </div>

                  <div className="p-3 bg-blue-50 rounded-lg">
                    <h4 className="font-semibold text-blue-800">Model Insights</h4>
                    <ul className="text-sm text-blue-700 mt-1 space-y-1">
                      <li>• Ensemble methods (RF, XGBoost) outperform single algorithms</li>
                      <li>• Tree-based models excel with complex feature interactions</li>
                      <li>• Low standard deviations indicate stable performance</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-blue-500" />
                  Recommendations
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="p-3 bg-yellow-50 rounded-lg">
                    <h4 className="font-semibold text-yellow-800">Production Deployment</h4>
                    <p className="text-sm text-yellow-700 mt-1">
                      Use <strong>Random Forest</strong> as the primary model for disease estimation due to its superior
                      accuracy and stability.
                    </p>
                  </div>

                  <div className="p-3 bg-purple-50 rounded-lg">
                    <h4 className="font-semibold text-purple-800">Model Ensemble</h4>
                    <p className="text-sm text-purple-700 mt-1">
                      Consider combining Random Forest and XGBoost predictions for even more robust estimations.
                    </p>
                  </div>

                  <div className="p-3 bg-gray-50 rounded-lg">
                    <h4 className="font-semibold text-gray-800">Future Improvements</h4>
                    <ul className="text-sm text-gray-700 mt-1 space-y-1">
                      <li>• Hyperparameter tuning for XGBoost</li>
                      <li>• Feature engineering optimization</li>
                      <li>• Cross-validation with temporal splits</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Performance Summary */}
          <Card>
            <CardHeader>
              <CardTitle>Performance Summary</CardTitle>
              <CardDescription>Statistical overview of model evaluation results</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">99.99%</div>
                  <div className="text-sm text-green-800">Best R² Score</div>
                  <div className="text-xs text-green-600">Random Forest</div>
                </div>
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">0.16</div>
                  <div className="text-sm text-blue-800">Lowest RMSE</div>
                  <div className="text-xs text-blue-600">Random Forest</div>
                </div>
                <div className="text-center p-4 bg-purple-50 rounded-lg">
                  <div className="text-2xl font-bold text-purple-600">85.6%</div>
                  <div className="text-sm text-purple-800">Average R²</div>
                  <div className="text-xs text-purple-600">All Models</div>
                </div>
                <div className="text-center p-4 bg-orange-50 rounded-lg">
                  <div className="text-2xl font-bold text-orange-600">5</div>
                  <div className="text-sm text-orange-800">Models Tested</div>
                  <div className="text-xs text-orange-600">ML Algorithms</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
} from "recharts"

const monthlyData = [
  { month: "Jan", measles: 45000, malaria: 85000, cholera: 12000 },
  { month: "Feb", measles: 52000, malaria: 92000, cholera: 15000 },
  { month: "Mar", measles: 67000, malaria: 110000, cholera: 18000 },
  { month: "Apr", measles: 89000, malaria: 135000, cholera: 25000 },
  { month: "May", measles: 125000, malaria: 165000, cholera: 35000 },
  { month: "Jun", measles: 98000, malaria: 145000, cholera: 28000 },
]

const regionData = [
  { name: "Bay", value: 1584745, color: "#ef4444" },
  { name: "Banadir", value: 1395002, color: "#f97316" },
  { name: "Bari", value: 510818, color: "#eab308" },
  { name: "Mudug", value: 443938, color: "#22c55e" },
  { name: "Lower Juba", value: 463953, color: "#3b82f6" },
  { name: "Others", value: 566492, color: "#8b5cf6" },
]

export function DiseaseCharts() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <Card>
        <CardHeader>
          <CardTitle>Simulated Monthly Disease Trends</CardTitle>
          <CardDescription>Projected monthly distribution based on annual data</CardDescription>
        </CardHeader>
        <CardContent>
          <ChartContainer
            config={{
              measles: { label: "Measles", color: "#ef4444" },
              malaria: { label: "Malaria", color: "#eab308" },
              cholera: { label: "Cholera", color: "#3b82f6" },
            }}
            className="h-80"
          >
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Line type="monotone" dataKey="measles" stroke="#ef4444" strokeWidth={2} />
                <Line type="monotone" dataKey="malaria" stroke="#eab308" strokeWidth={2} />
                <Line type="monotone" dataKey="cholera" stroke="#3b82f6" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </ChartContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Cases by Region</CardTitle>
          <CardDescription>Distribution of total cases across regions</CardDescription>
        </CardHeader>
        <CardContent>
          <ChartContainer
            config={{
              value: { label: "Cases", color: "#3b82f6" },
            }}
            className="h-80"
          >
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={regionData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {regionData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <ChartTooltip content={<ChartTooltipContent />} />
              </PieChart>
            </ResponsiveContainer>
          </ChartContainer>
        </CardContent>
      </Card>

      <Card className="lg:col-span-2">
        <CardHeader>
          <CardTitle>Disease Comparison by Major Districts</CardTitle>
          <CardDescription>Top districts with highest disease burden from actual survey data</CardDescription>
        </CardHeader>
        <CardContent>
          <ChartContainer
            config={{
              measles: { label: "Measles", color: "#ef4444" },
              malaria: { label: "Malaria", color: "#eab308" },
              cholera: { label: "Cholera", color: "#3b82f6" },
            }}
            className="h-80"
          >
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={[
                  { district: "Burhakaba", measles: 717690, malaria: 155883, cholera: 300719 },
                  { district: "Banadir", measles: 577188, malaria: 158099, cholera: 659715 },
                  { district: "Baidoa", measles: 150730, malaria: 88047, cholera: 73216 },
                  { district: "Gaalkacyo", measles: 150000, malaria: 20000, cholera: 200000 },
                  { district: "Jamaame", measles: 100000, malaria: 40000, cholera: 210000 },
                  { district: "Bossaso", measles: 98291, malaria: 112030, cholera: 275850 },
                  { district: "Dinsoor", measles: 72459, malaria: 26000, cholera: 0 },
                  { district: "Kismayo", measles: 51000, malaria: 50613, cholera: 12340 },
                ]}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="district" angle={-45} textAnchor="end" height={80} />
                <YAxis />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Bar dataKey="measles" fill="#ef4444" />
                <Bar dataKey="malaria" fill="#eab308" />
                <Bar dataKey="cholera" fill="#3b82f6" />
              </BarChart>
            </ResponsiveContainer>
          </ChartContainer>
        </CardContent>
      </Card>
    </div>
  )
}

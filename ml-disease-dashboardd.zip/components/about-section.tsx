"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import {
  Users,
  Target,
  Database,
  Brain,
  MapPin,
  Calendar,
  GraduationCap,
  Code,
  BarChart3,
  Shield,
  User,
} from "lucide-react"

export function AboutSection() {
  const teamMembers = [
    {
      name: "Hussein Ali Salad",
      role: "Lead Developer & Project Manager",
      icon: <User className="h-6 w-6" />,
      responsibilities: ["Machine Learning Model Development", "System Architecture & Design", "Frontend Development"],
      color: "bg-blue-100 text-blue-800",
    },
    {
      name: "Ahmed Muse Ahmed",
      role: "Co-Developer & Research Partner",
      icon: <Code className="h-6 w-6" />,
      responsibilities: ["Data Analysis & Preprocessing", "Backend Development", "Testing & Quality Assurance"],
      color: "bg-green-100 text-green-800",
    },
    {
      name: "DR Abdi Jalil",
      role: "Project Supervisor",
      icon: <GraduationCap className="h-6 w-6" />,
      responsibilities: [
        "Academic guidance and oversight",
        "Research methodology supervision",
        "Project evaluation and assessment",
      ],
      color: "bg-purple-100 text-purple-800",
      isAcademic: true,
    },
  ]

  const projectStats = [
    { label: "Regions Covered", value: "17", icon: <MapPin className="h-5 w-5" /> },
    { label: "Districts Surveyed", value: "51", icon: <Database className="h-5 w-5" /> },
    { label: "Disease Types", value: "3", icon: <Target className="h-5 w-5" /> },
    { label: "ML Models", value: "5", icon: <Brain className="h-5 w-5" /> },
  ]

  return (
    <div className="space-y-6">
      {/* Project Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-6 w-6" />
            Project Overview
          </CardTitle>
          <CardDescription>
            Somalia Disease Surveillance Dashboard - A comprehensive machine learning solution for disease prediction
            and monitoring
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {projectStats.map((stat, index) => (
              <div key={index} className="text-center p-4 bg-gray-50 rounded-lg">
                <div className="flex justify-center mb-2 text-blue-600">{stat.icon}</div>
                <div className="text-2xl font-bold text-gray-900">{stat.value}</div>
                <div className="text-sm text-gray-600">{stat.label}</div>
              </div>
            ))}
          </div>

          <div className="prose max-w-none">
            <p className="text-gray-700 leading-relaxed">
              This project represents a cutting-edge approach to disease surveillance in Somalia, combining advanced
              machine learning techniques with comprehensive health data analysis. Our system processes data from 51
              districts across all 17 regions of Somalia, focusing on three major diseases: measles, malaria, and
              cholera.
            </p>
            <p className="text-gray-700 leading-relaxed mt-4">
              The dashboard provides real-time monitoring capabilities, predictive analytics, and interactive
              visualizations to support public health decision-making and early warning systems for disease outbreaks.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Development Team */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-6 w-6" />
            Development Team
          </CardTitle>
          <CardDescription>Meet the dedicated team behind the Somalia Disease Surveillance Dashboard</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {teamMembers.map((member, index) => (
              <div key={index}>
                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center">
                      {member.icon}
                    </div>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-lg font-semibold text-gray-900">{member.name}</h3>
                      <Badge className={member.color}>
                        {member.isAcademic && <GraduationCap className="h-3 w-3 mr-1" />}
                        {member.role}
                      </Badge>
                    </div>
                    <div className="space-y-1">
                      {member.responsibilities.map((responsibility, idx) => (
                        <div key={idx} className="flex items-center text-sm text-gray-600">
                          <div className="w-1.5 h-1.5 bg-blue-500 rounded-full mr-2 flex-shrink-0"></div>
                          {responsibility}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
                {index < teamMembers.length - 1 && <Separator className="mt-6" />}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Academic Support */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <GraduationCap className="h-6 w-6" />
            Academic Support
          </CardTitle>
          <CardDescription>This project is conducted under academic supervision at SIMAD University</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="bg-blue-50 p-4 rounded-lg">
            <div className="flex items-center gap-3 mb-3">
              <Shield className="h-5 w-5 text-blue-600" />
              <span className="font-semibold text-blue-900">Academic Oversight</span>
            </div>
            <p className="text-blue-800 text-sm">
              This project is being developed as part of the Bachelor of Information Technology (BIT) program at SIMAD
              University, under the supervision of qualified academic staff who provide guidance on research
              methodology, technical implementation, and project evaluation.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Technical Specifications */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-6 w-6" />
            Technical Specifications
          </CardTitle>
          <CardDescription>Technologies and methodologies used in the development of this system</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold mb-3 flex items-center gap-2">
                <Code className="h-4 w-4" />
                Frontend Technologies
              </h4>
              <div className="space-y-2">
                <Badge variant="outline">Next.js 14</Badge>
                <Badge variant="outline">React 18</Badge>
                <Badge variant="outline">TypeScript</Badge>
                <Badge variant="outline">Tailwind CSS</Badge>
                <Badge variant="outline">Shadcn/ui</Badge>
              </div>
            </div>
            <div>
              <h4 className="font-semibold mb-3 flex items-center gap-2">
                <Brain className="h-4 w-4" />
                Machine Learning
              </h4>
              <div className="space-y-2">
                <Badge variant="outline">Random Forest</Badge>
                <Badge variant="outline">XGBoost</Badge>
                <Badge variant="outline">K-Nearest Neighbors</Badge>
                <Badge variant="outline">Support Vector Regression</Badge>
                <Badge variant="outline">Linear Regression</Badge>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Project Timeline */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-6 w-6" />
            Project Timeline
          </CardTitle>
          <CardDescription>Development phases and milestones</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <div className="w-3 h-3 bg-green-500 rounded-full"></div>
              <div>
                <div className="font-medium">Data Collection & Analysis</div>
                <div className="text-sm text-gray-600">SMART survey data processing and validation</div>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="w-3 h-3 bg-green-500 rounded-full"></div>
              <div>
                <div className="font-medium">Machine Learning Model Development</div>
                <div className="text-sm text-gray-600">Training and optimization of prediction models</div>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="w-3 h-3 bg-green-500 rounded-full"></div>
              <div>
                <div className="font-medium">Dashboard Development</div>
                <div className="text-sm text-gray-600">Interactive web application with real-time analytics</div>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
              <div>
                <div className="font-medium">Testing & Deployment</div>
                <div className="text-sm text-gray-600">System validation and production deployment</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Database,
  MapPin,
  Users,
  Activity,
  TrendingUp,
  AlertTriangle,
  BarChart3,
  PieChart,
  LineChart,
  Eye,
} from "lucide-react"
import { DataViewModal } from "./data-view-modal"
import { useAuth } from "@/contexts/auth-context"

export function DataOverview() {
  const [showDataModal, setShowDataModal] = useState(false)
  const { user } = useAuth()

  // Real survey statistics
  const surveyStats = {
    totalRegions: 17,
    totalDistricts: 51,
    coverage: 100,
    dataPoints: 40127, // Your actual dataset size
    diseases: 3,
  }

  // Disease totals from the survey
  const diseaseStats = {
    measles: 689141,
    malaria: 853265,
    cholera: 1436958,
  }

  return (
    <div className="space-y-6">
      {/* Key Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <MapPin className="h-8 w-8 text-blue-600" />
              <div>
                <p className="text-sm font-medium text-gray-600">Regions Covered</p>
                <p className="text-3xl font-bold">{surveyStats.totalRegions}</p>
                <p className="text-xs text-green-600">100% Coverage</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Users className="h-8 w-8 text-green-600" />
              <div>
                <p className="text-sm font-medium text-gray-600">Districts Surveyed</p>
                <p className="text-3xl font-bold">{surveyStats.totalDistricts}</p>
                <p className="text-xs text-blue-600">SMART Survey</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Database className="h-8 w-8 text-purple-600" />
              <div>
                <p className="text-sm font-medium text-gray-600">Data Points</p>
                <p className="text-3xl font-bold">{surveyStats.dataPoints.toLocaleString()}</p>
                <p className="text-xs text-purple-600">Records</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Activity className="h-8 w-8 text-orange-600" />
              <div>
                <p className="text-sm font-medium text-gray-600">Diseases Tracked</p>
                <p className="text-3xl font-bold">{surveyStats.diseases}</p>
                <p className="text-xs text-orange-600">Major Diseases</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Disease Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="border-l-4 border-l-red-500">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-red-500" />
              Measles Cases
            </CardTitle>
            <CardDescription>Vaccine-preventable disease</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600 mb-2">{diseaseStats.measles.toLocaleString()}</div>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Banadir Region</span>
                <span className="font-medium">83.7%</span>
              </div>
              <Progress value={83.7} className="h-2" />
              <p className="text-xs text-gray-600">Highly concentrated in urban areas</p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-yellow-500">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <Activity className="h-5 w-5 text-yellow-500" />
              Malaria Cases
            </CardTitle>
            <CardDescription>Vector-borne disease</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600 mb-2">{diseaseStats.malaria.toLocaleString()}</div>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Environmental factors</span>
                <span className="font-medium">High</span>
              </div>
              <Progress value={65} className="h-2" />
              <p className="text-xs text-gray-600">More evenly distributed across regions</p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-blue-500">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <Database className="h-5 w-5 text-blue-500" />
              Cholera Cases
            </CardTitle>
            <CardDescription>Water-related disease</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600 mb-2">{diseaseStats.cholera.toLocaleString()}</div>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Coastal regions</span>
                <span className="font-medium">70.4%</span>
              </div>
              <Progress value={70.4} className="h-2" />
              <p className="text-xs text-gray-600">WASH interventions needed</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Analytics Preview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Analytics Preview
          </CardTitle>
          <CardDescription>Quick insights from the Somalia SMART survey data</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="relative group cursor-pointer rounded-lg overflow-hidden bg-gradient-to-br from-blue-500 to-blue-600 p-6 text-white">
              <div className="flex items-center justify-between mb-4">
                <BarChart3 className="h-8 w-8" />
                <Badge variant="secondary" className="bg-white/20 text-white">
                  Regional
                </Badge>
              </div>
              <h3 className="text-lg font-semibold mb-2">Disease Distribution</h3>
              <p className="text-sm opacity-90">Compare disease burden across all 17 regions of Somalia</p>
              <div className="absolute inset-0 bg-black/10 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <span className="text-white font-medium">View in Analytics →</span>
              </div>
            </div>

            <div className="relative group cursor-pointer rounded-lg overflow-hidden bg-gradient-to-br from-green-500 to-green-600 p-6 text-white">
              <div className="flex items-center justify-between mb-4">
                <PieChart className="h-8 w-8" />
                <Badge variant="secondary" className="bg-white/20 text-white">
                  Coverage
                </Badge>
              </div>
              <h3 className="text-lg font-semibold mb-2">Survey Coverage</h3>
              <p className="text-sm opacity-90">100% coverage across 51 districts in Somalia</p>
              <div className="absolute inset-0 bg-black/10 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <span className="text-white font-medium">View in Analytics →</span>
              </div>
            </div>

            <div className="relative group cursor-pointer rounded-lg overflow-hidden bg-gradient-to-br from-purple-500 to-purple-600 p-6 text-white">
              <div className="flex items-center justify-between mb-4">
                <LineChart className="h-8 w-8" />
                <Badge variant="secondary" className="bg-white/20 text-white">
                  Trends
                </Badge>
              </div>
              <h3 className="text-lg font-semibold mb-2">Disease Patterns</h3>
              <p className="text-sm opacity-90">Epidemiological insights and hotspot analysis</p>
              <div className="absolute inset-0 bg-black/10 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <span className="text-white font-medium">View in Analytics →</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Key Insights */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            Key Survey Insights
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h4 className="font-semibold text-gray-800">Geographic Patterns</h4>
              <ul className="space-y-2 text-sm text-gray-600">
                <li className="flex items-start gap-2">
                  <div className="w-2 h-2 bg-red-500 rounded-full mt-2 flex-shrink-0"></div>
                  <span>
                    <strong>Measles:</strong> Highly concentrated in Banadir (urban center) - 83.7% of all cases
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <div className="w-2 h-2 bg-yellow-500 rounded-full mt-2 flex-shrink-0"></div>
                  <span>
                    <strong>Malaria:</strong> Environmental factors drive distribution, high in Gedo region
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
                  <span>
                    <strong>Cholera:</strong> Coastal regions and water access issues drive 70.4% of cases
                  </span>
                </li>
              </ul>
            </div>

            <div className="space-y-4">
              <h4 className="font-semibold text-gray-800">Survey Coverage</h4>
              <ul className="space-y-2 text-sm text-gray-600">
                <li className="flex items-start gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                  <span>
                    <strong>Complete Coverage:</strong> All 17 regions of Somalia included
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <div className="w-2 h-2 bg-purple-500 rounded-full mt-2 flex-shrink-0"></div>
                  <span>
                    <strong>District Level:</strong> 51 districts surveyed with high data quality
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <div className="w-2 h-2 bg-orange-500 rounded-full mt-2 flex-shrink-0"></div>
                  <span>
                    <strong>Data Points:</strong> {surveyStats.dataPoints.toLocaleString()} records for analysis
                  </span>
                </li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Data Access - Only for administrators */}
      {user?.role === "admin" && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="h-5 w-5" />
              Dataset Access
            </CardTitle>
            <CardDescription>View and explore the complete Somalia SMART survey dataset</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-2">
                  Access the complete dataset with {surveyStats.dataPoints.toLocaleString()} records covering 51
                  districts across Somalia
                </p>
                <div className="flex gap-2">
                  <Badge variant="outline">Excel-like viewer</Badge>
                  <Badge variant="outline">Search & filter</Badge>
                  <Badge variant="outline">Export CSV</Badge>
                </div>
              </div>
              <Button onClick={() => setShowDataModal(true)} className="flex items-center gap-2">
                <Eye className="h-4 w-4" />
                View Original Dataset
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Data View Modal - Only for administrators */}
      {user?.role === "admin" && <DataViewModal isOpen={showDataModal} onClose={() => setShowDataModal(false)} />}
    </div>
  )
}

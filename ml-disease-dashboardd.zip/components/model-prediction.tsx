"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Brain, Calculator, Settings, CheckCircle, AlertCircle, TrendingUp, MapPin } from "lucide-react"

import { HistoricalDataViewer } from "./historical-data-viewer"
import { ModelSetupGuide } from "./model-setup-guide"
import { ModelVerification } from "./model-verification"
import { onnxModelManager, type PredictionInput } from "@/lib/onnx-model-manager"

export function ModelPrediction() {
  const [selectedModel, setSelectedModel] = useState("Random Forest")
  const [isLoading, setIsLoading] = useState(false)
  const [prediction, setPrediction] = useState<any | null>(null)
  const [predictionInput, setPredictionInput] = useState<PredictionInput>({
    region: "Banadir",
    district: "Banadir",
    population: 1600000,
    rainfall: 600,
    quality_score: 87.1,
    prop_idp: 0.15,
    sam_rate: 0.8,
    vaccination_coverage: 74,
    year: 2025,
  })

  const availableModels = [
    { name: "Random Forest", accuracy: 99.99, description: "Ensemble method with high accuracy" },
    { name: "XGBoost", accuracy: 99.94, description: "Gradient boosting with excellent performance" },
    { name: "K-Nearest Neighbors", accuracy: 99.31, description: "Instance-based learning algorithm" },
    { name: "Support Vector Regression", accuracy: 85.23, description: "Kernel-based regression method" },
    { name: "Linear Regression", accuracy: 43.07, description: "Simple linear relationship model" },
  ]

  const somaliaRegions = [
    "Awdal",
    "Banadir",
    "Bari",
    "Bay",
    "Bakool",
    "Galguduud",
    "Gedo",
    "Hiraan",
    "Lower Juba",
    "Lower Shabelle",
    "Middle Juba",
    "Middle Shabelle",
    "Mudug",
    "Nugaal",
    "Sanaag",
    "Sool",
    "Togdheer",
    "Woqooyi_Galbeed",
  ]

  const handlePredict = async () => {
    setIsLoading(true)
    try {
      console.log("🔮 Starting prediction with input:", predictionInput)
      const result = await onnxModelManager.predict(predictionInput, selectedModel)
      setPrediction(result)
      console.log("✅ Prediction result:", result)
    } catch (error) {
      console.error("❌ Prediction error:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleInputChange = (field: keyof PredictionInput, value: string | number) => {
    setPredictionInput((prev) => ({
      ...prev,
      [field]: typeof value === "string" ? (isNaN(Number(value)) ? value : Number(value)) : value,
    }))
  }

  const getModelBadgeVariant = (accuracy: number) => {
    if (accuracy >= 95) return "default"
    if (accuracy >= 80) return "secondary"
    return "outline"
  }

  const getPredictionSeverity = (cases: number, population: number) => {
    const rate = (cases / population) * 100000 // Cases per 100k
    if (rate > 5000) return { level: "High", color: "text-red-600", bg: "bg-red-50" }
    if (rate > 2000) return { level: "Medium", color: "text-yellow-600", bg: "bg-yellow-50" }
    return { level: "Low", color: "text-green-600", bg: "bg-green-50" }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-6 w-6" />
            Machine Learning Disease Prediction Models
          </CardTitle>
          <CardDescription>
            Advanced ML models for predicting disease cases in Somalia using 43+ features and historical data patterns
          </CardDescription>
        </CardHeader>
      </Card>

      <Tabs defaultValue="historical" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="historical">Historical Data</TabsTrigger>
          <TabsTrigger value="prediction">2025 Estimation</TabsTrigger>
          <TabsTrigger value="setup">Setup Guide</TabsTrigger>
          <TabsTrigger value="verify">Verify Setup</TabsTrigger>
        </TabsList>

        {/* Historical Data Tab */}
        <TabsContent value="historical">
          <HistoricalDataViewer />
        </TabsContent>

        {/* Prediction Tab */}
        <TabsContent value="prediction" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Model Selection */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="h-5 w-5" />
                  Model Selection & Parameters
                </CardTitle>
                <CardDescription>Choose your ML model and configure prediction parameters</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Model Selection */}
                <div className="space-y-3">
                  <Label>Machine Learning Model</Label>
                  <Select value={selectedModel} onValueChange={setSelectedModel}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {availableModels.map((model) => (
                        <SelectItem key={model.name} value={model.name}>
                          <div className="flex items-center justify-between w-full">
                            <span>{model.name}</span>
                            <Badge variant={getModelBadgeVariant(model.accuracy)} className="ml-2">
                              {model.accuracy.toFixed(2)}%
                            </Badge>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="text-sm text-gray-600">
                    {availableModels.find((m) => m.name === selectedModel)?.description}
                  </p>
                </div>

                {/* Input Parameters */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Region</Label>
                    <Select
                      value={predictionInput.region}
                      onValueChange={(value) => handleInputChange("region", value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {somaliaRegions.map((region) => (
                          <SelectItem key={region} value={region}>
                            {region}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>District</Label>
                    <Input
                      value={predictionInput.district}
                      onChange={(e) => handleInputChange("district", e.target.value)}
                      placeholder="Enter district name"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Population</Label>
                    <Input
                      type="number"
                      value={predictionInput.population}
                      onChange={(e) => handleInputChange("population", e.target.value)}
                      placeholder="Population size"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Annual Rainfall (mm)</Label>
                    <Input
                      type="number"
                      value={predictionInput.rainfall}
                      onChange={(e) => handleInputChange("rainfall", e.target.value)}
                      placeholder="Rainfall in mm"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Health Quality Score</Label>
                    <Input
                      type="number"
                      step="0.1"
                      min="0"
                      max="100"
                      value={predictionInput.quality_score}
                      onChange={(e) => handleInputChange("quality_score", e.target.value)}
                      placeholder="0-100"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>IDP Proportion</Label>
                    <Input
                      type="number"
                      step="0.01"
                      min="0"
                      max="1"
                      value={predictionInput.prop_idp}
                      onChange={(e) => handleInputChange("prop_idp", e.target.value)}
                      placeholder="0.0-1.0"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>SAM Rate (%)</Label>
                    <Input
                      type="number"
                      step="0.1"
                      min="0"
                      value={predictionInput.sam_rate}
                      onChange={(e) => handleInputChange("sam_rate", e.target.value)}
                      placeholder="Malnutrition rate"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Vaccination Coverage (%)</Label>
                    <Input
                      type="number"
                      min="0"
                      max="100"
                      value={predictionInput.vaccination_coverage}
                      onChange={(e) => handleInputChange("vaccination_coverage", e.target.value)}
                      placeholder="0-100"
                    />
                  </div>
                </div>

                <Button onClick={handlePredict} disabled={isLoading} className="w-full" size="lg">
                  {isLoading ? (
                    <>
                      <Calculator className="h-4 w-4 mr-2 animate-spin" />
                      Predicting 2025 Cases...
                    </>
                  ) : (
                    <>
                      <Calculator className="h-4 w-4 mr-2" />
                      Predict 2025 Cases
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            {/* Prediction Results */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  2025 Disease Prediction Results
                </CardTitle>
                <CardDescription>ML-powered disease case predictions for the selected region</CardDescription>
              </CardHeader>
              <CardContent>
                {prediction ? (
                  <div className="space-y-6">
                    {/* Model Info */}
                    <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                      <div className="flex items-center gap-2">
                        <CheckCircle className="h-5 w-5 text-blue-600" />
                        <span className="font-medium">Model: {prediction.model_used}</span>
                      </div>
                      <Badge variant="default">{(prediction.confidence * 100).toFixed(1)}% Confidence</Badge>
                    </div>

                    {/* Location Info */}
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <MapPin className="h-4 w-4" />
                      <span>
                        {predictionInput.district}, {predictionInput.region} Region
                      </span>
                      <Badge variant="outline">Pop: {predictionInput.population.toLocaleString()}</Badge>
                    </div>

                    {/* Disease Predictions */}
                    <div className="space-y-4">
                      {/* Measles */}
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                            <span className="font-medium">Measles Cases</span>
                          </div>
                          <div className="text-right">
                            <div className="text-2xl font-bold text-red-600">{prediction.measles.toLocaleString()}</div>
                            <Badge
                              variant={
                                getPredictionSeverity(prediction.measles, predictionInput.population).level === "High"
                                  ? "destructive"
                                  : "secondary"
                              }
                            >
                              {getPredictionSeverity(prediction.measles, predictionInput.population).level} Risk
                            </Badge>
                          </div>
                        </div>
                        <Progress
                          value={Math.min(100, ((prediction.measles / predictionInput.population) * 100000) / 100)}
                          className="h-2"
                        />
                        <p className="text-sm text-gray-600">
                          Rate: {((prediction.measles / predictionInput.population) * 100000).toFixed(1)} per 100,000
                        </p>
                      </div>

                      {/* Malaria */}
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                            <span className="font-medium">Malaria Cases</span>
                          </div>
                          <div className="text-right">
                            <div className="text-2xl font-bold text-yellow-600">
                              {prediction.malaria.toLocaleString()}
                            </div>
                            <Badge
                              variant={
                                getPredictionSeverity(prediction.malaria, predictionInput.population).level === "High"
                                  ? "destructive"
                                  : "secondary"
                              }
                            >
                              {getPredictionSeverity(prediction.malaria, predictionInput.population).level} Risk
                            </Badge>
                          </div>
                        </div>
                        <Progress
                          value={Math.min(100, ((prediction.malaria / predictionInput.population) * 100000) / 200)}
                          className="h-2"
                        />
                        <p className="text-sm text-gray-600">
                          Rate: {((prediction.malaria / predictionInput.population) * 100000).toFixed(1)} per 100,000
                        </p>
                      </div>

                      {/* Cholera */}
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                            <span className="font-medium">Cholera Cases</span>
                          </div>
                          <div className="text-right">
                            <div className="text-2xl font-bold text-blue-600">
                              {prediction.cholera.toLocaleString()}
                            </div>
                            <Badge
                              variant={
                                getPredictionSeverity(prediction.cholera, predictionInput.population).level === "High"
                                  ? "destructive"
                                  : "secondary"
                              }
                            >
                              {getPredictionSeverity(prediction.cholera, predictionInput.population).level} Risk
                            </Badge>
                          </div>
                        </div>
                        <Progress
                          value={Math.min(100, ((prediction.cholera / predictionInput.population) * 100000) / 150)}
                          className="h-2"
                        />
                        <p className="text-sm text-gray-600">
                          Rate: {((prediction.cholera / predictionInput.population) * 100000).toFixed(1)} per 100,000
                        </p>
                      </div>
                    </div>

                    {/* Total Summary */}
                    <div className="p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center justify-between">
                        <span className="font-medium">Total Predicted Cases</span>
                        <span className="text-2xl font-bold">
                          {(prediction.measles + prediction.malaria + prediction.cholera).toLocaleString()}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600">
                        Combined disease burden for {predictionInput.district} district in 2025
                      </p>
                    </div>

                    {/* Recommendations */}
                    <Alert>
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription>
                        <strong>Recommendations:</strong> Based on the predictions, focus on{" "}
                        {prediction.malaria > prediction.measles && prediction.malaria > prediction.cholera
                          ? "malaria prevention and vector control"
                          : prediction.measles > prediction.cholera
                            ? "vaccination campaigns and measles prevention"
                            : "water sanitation and cholera prevention"}{" "}
                        measures for 2025.
                      </AlertDescription>
                    </Alert>
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Brain className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No Predictions Yet</h3>
                    <p className="text-gray-600 mb-4">
                      Configure your parameters and click "Predict 2025 Cases" to see ML-powered disease predictions.
                    </p>
                    <div className="text-sm text-gray-500">
                      <p>• Uses 43+ features for accurate predictions</p>
                      <p>• Based on 2020-2024 historical data</p>
                      <p>• Multiple ML algorithms available</p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Model Comparison */}
          <Card>
            <CardHeader>
              <CardTitle>Available ML Models</CardTitle>
              <CardDescription>
                Compare different machine learning algorithms and their performance metrics
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
                {availableModels.map((model) => (
                  <Card
                    key={model.name}
                    className={`cursor-pointer transition-all hover:shadow-md ${
                      selectedModel === model.name ? "ring-2 ring-blue-500 bg-blue-50" : ""
                    }`}
                    onClick={() => setSelectedModel(model.name)}
                  >
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">{model.name}</CardTitle>
                      <Badge variant={getModelBadgeVariant(model.accuracy)}>
                        {model.accuracy.toFixed(2)}% Accuracy
                      </Badge>
                    </CardHeader>
                    <CardContent>
                      <p className="text-xs text-gray-600">{model.description}</p>
                      <div className="mt-2">
                        <Progress value={model.accuracy} className="h-2" />
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Setup Guide Tab */}
        <TabsContent value="setup">
          <ModelSetupGuide />
        </TabsContent>

        {/* Verify Setup Tab */}
        <TabsContent value="verify">
          <ModelVerification />
        </TabsContent>
      </Tabs>
    </div>
  )
}

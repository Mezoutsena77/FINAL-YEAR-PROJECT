"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Image from "next/image"

export default function SystemDiagrams() {
  const diagrams = [
    {
      title: "System Architecture",
      image: "/images/system-architecture.png",
      description: "Complete system architecture showing data flow from SMART surveys to dashboard visualization",
      category: "Architecture",
    },
    {
      title: "Data Flow Diagram",
      image: "/images/data-flow-diagram.png",
      description: "Detailed data processing pipeline from raw CSV to predictions",
      category: "Data Processing",
    },
    {
      title: "Machine Learning Pipeline",
      image: "/images/ml-pipeline.png",
      description: "ML workflow including training, validation, and deployment phases",
      category: "Machine Learning",
    },
    {
      title: "Database Schema",
      image: "/images/database-schema.png",
      description: "Database design showing tables and relationships for survey data",
      category: "Database",
    },
    {
      title: "User Interface Design",
      image: "/images/user-interface-mockup.png",
      description: "Dashboard interface mockup with map, charts, and admin features",
      category: "UI/UX",
    },
    {
      title: "Deployment Architecture",
      image: "/images/deployment-architecture.png",
      description: "Cloud infrastructure and deployment configuration",
      category: "Deployment",
    },
    {
      title: "Security Model",
      image: "/images/security-model.png",
      description: "Authentication, authorization, and data security framework",
      category: "Security",
    },
    {
      title: "Geographic Coverage",
      image: "/images/geographic-coverage.png",
      description: "Somalia regions and districts covered by SMART surveys",
      category: "Geographic",
    },
  ]

  const categories = [...new Set(diagrams.map((d) => d.category))]

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h1 className="text-3xl font-bold mb-4">System Design Diagrams</h1>
        <p className="text-gray-600 max-w-2xl mx-auto">
          Comprehensive visual documentation of the Somalia Disease Surveillance Dashboard system architecture, data
          flow, and technical implementation.
        </p>
      </div>

      {categories.map((category) => (
        <div key={category} className="space-y-4">
          <h2 className="text-2xl font-semibold text-gray-800 border-b pb-2">{category} Diagrams</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {diagrams
              .filter((diagram) => diagram.category === category)
              .map((diagram, index) => (
                <Card key={index} className="overflow-hidden hover:shadow-lg transition-shadow">
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start">
                      <CardTitle className="text-lg">{diagram.title}</CardTitle>
                      <Badge variant="secondary">{diagram.category}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="relative aspect-video bg-gray-100 rounded-lg overflow-hidden">
                      <Image
                        src={diagram.image || "/placeholder.svg"}
                        alt={diagram.title}
                        fill
                        className="object-cover"
                        sizes="(max-width: 768px) 100vw, 50vw"
                      />
                    </div>
                    <p className="text-sm text-gray-600">{diagram.description}</p>
                  </CardContent>
                </Card>
              ))}
          </div>
        </div>
      ))}

      <div className="bg-blue-50 p-6 rounded-lg">
        <h3 className="text-lg font-semibold mb-3">Usage Instructions</h3>
        <ul className="space-y-2 text-sm text-gray-700">
          <li>
            • <strong>System Architecture:</strong> Use for technical documentation and thesis Chapter 3
          </li>
          <li>
            • <strong>Data Flow:</strong> Include in methodology section to show data processing
          </li>
          <li>
            • <strong>ML Pipeline:</strong> Perfect for explaining machine learning approach
          </li>
          <li>
            • <strong>Database Schema:</strong> Use in technical appendix or system design section
          </li>
          <li>
            • <strong>UI Design:</strong> Include in user interface documentation
          </li>
          <li>
            • <strong>Deployment:</strong> Use for infrastructure and deployment chapters
          </li>
          <li>
            • <strong>Security:</strong> Include in security and privacy sections
          </li>
          <li>
            • <strong>Geographic:</strong> Use to show project scope and coverage area
          </li>
        </ul>
      </div>
    </div>
  )
}

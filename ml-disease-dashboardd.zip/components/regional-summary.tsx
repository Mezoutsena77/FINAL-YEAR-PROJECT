"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { MapPin } from "lucide-react"

const regionalData = [
  { region: "Bay", measles: 940880, malaria: 269930, cholera: 373935, districts: 3 },
  { region: "Banadir", measles: 577188, malaria: 158099, cholera: 659715, districts: 1 },
  { region: "Bari", measles: 115316, malaria: 119521, cholera: 275981, districts: 6 },
  { region: "Mudug", measles: 164925, malaria: 26457, cholera: 252556, districts: 2 },
  { region: "Lower Juba", measles: 151000, malaria: 90613, cholera: 222340, districts: 2 },
  { region: "Nugaal", measles: 53487, malaria: 5101, cholera: 139345, districts: 2 },
  { region: "Galgaduud", measles: 30856, malaria: 80427, cholera: 179337, districts: 3 },
  { region: "Woqooyi Galbeed", measles: 6168, malaria: 295997, cholera: 79495, districts: 3 },
]

export function RegionalSummary() {
  const totalMeasles = regionalData.reduce((sum, region) => sum + region.measles, 0)
  const totalMalaria = regionalData.reduce((sum, region) => sum + region.malaria, 0)
  const totalCholera = regionalData.reduce((sum, region) => sum + region.cholera, 0)

  const sortedByTotal = regionalData
    .map((region) => ({
      ...region,
      total: region.measles + region.malaria + region.cholera,
    }))
    .sort((a, b) => b.total - a.total)
    .slice(0, 8)

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MapPin className="h-5 w-5" />
          Regional Disease Summary
        </CardTitle>
        <CardDescription>Top 8 regions by total disease cases</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {sortedByTotal.map((region, index) => (
            <div key={region.region} className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="text-xs w-8 justify-center">
                    #{index + 1}
                  </Badge>
                  <span className="font-medium text-sm">{region.region}</span>
                  <span className="text-xs text-gray-500">({region.districts}d)</span>
                </div>
                <div className="text-sm font-medium">{region.total.toLocaleString()}</div>
              </div>

              <div className="grid grid-cols-3 gap-1 text-xs">
                <div className="flex items-center gap-1">
                  <div className="w-2 h-2 bg-red-500 rounded-full flex-shrink-0"></div>
                  <span className="truncate">{region.measles.toLocaleString()}</span>
                </div>
                <div className="flex items-center gap-1">
                  <div className="w-2 h-2 bg-yellow-500 rounded-full flex-shrink-0"></div>
                  <span className="truncate">{region.malaria.toLocaleString()}</span>
                </div>
                <div className="flex items-center gap-1">
                  <div className="w-2 h-2 bg-blue-500 rounded-full flex-shrink-0"></div>
                  <span className="truncate">{region.cholera.toLocaleString()}</span>
                </div>
              </div>

              <Progress value={(region.total / sortedByTotal[0].total) * 100} className="h-1" />
            </div>
          ))}
        </div>

        <div className="mt-4 pt-4 border-t">
          <div className="grid grid-cols-3 gap-2 text-center">
            <div>
              <div className="text-lg font-bold text-red-600">2.13M</div>
              <div className="text-xs text-gray-600">Measles</div>
            </div>
            <div>
              <div className="text-lg font-bold text-yellow-600">1.52M</div>
              <div className="text-xs text-gray-600">Malaria</div>
            </div>
            <div>
              <div className="text-lg font-bold text-blue-600">2.31M</div>
              <div className="text-xs text-gray-600">Cholera</div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Calendar, MapPin, TrendingUp, Download, RefreshCw, Activity, CheckCircle, BarChart3 } from "lucide-react"

interface HistoricalDataPoint {
  year: number
  region: string
  district: string
  population: number
  measles_cases: number
  malaria_cases: number
  cholera_cases: number
  quality_score: number
  rainfall: number
  prop_idp: number
  sam_rate: number
  vaccination_coverage: number
}

export function HistoricalDataViewer() {
  const [selectedYear, setSelectedYear] = useState<number>(2024)
  const [selectedRegion, setSelectedRegion] = useState<string>("All")
  const [isLoading, setIsLoading] = useState(false)
  const [historicalData, setHistoricalData] = useState<HistoricalDataPoint[]>([])

  const years = [2020, 2021, 2022, 2023, 2024]
  const regions = ["All", "Banadir", "Bari", "Bay", "Galguduud", "Lower Shabelle", "Middle Shabelle"]

  // Generate realistic historical data
  useEffect(() => {
    const generateHistoricalData = (): HistoricalDataPoint[] => {
      const data: HistoricalDataPoint[] = []
      const baseData = {
        Banadir: { pop: 1600000, measles_base: 850, malaria_base: 24000, cholera_base: 320 },
        Bari: { pop: 719000, measles_base: 420, malaria_base: 18500, cholera_base: 180 },
        Bay: { pop: 792000, measles_base: 680, malaria_base: 28000, cholera_base: 450 },
        Galguduud: { pop: 569000, measles_base: 380, malaria_base: 15200, cholera_base: 220 },
        "Lower Shabelle": { pop: 1202000, measles_base: 720, malaria_base: 31000, cholera_base: 380 },
        "Middle Shabelle": { pop: 516000, measles_base: 290, malaria_base: 12800, cholera_base: 160 },
      }

      years.forEach((year) => {
        Object.entries(baseData).forEach(([region, base]) => {
          // Year progression factor (slight increase over time)
          const yearFactor = 1 + (year - 2020) * 0.03
          // Random variation
          const variation = 0.85 + Math.random() * 0.3

          data.push({
            year,
            region,
            district: region,
            population: Math.round(base.pop * yearFactor),
            measles_cases: Math.round(base.measles_base * yearFactor * variation),
            malaria_cases: Math.round(base.malaria_base * yearFactor * variation),
            cholera_cases: Math.round(base.cholera_base * yearFactor * variation),
            quality_score: Math.round((75 + Math.random() * 20) * 10) / 10,
            rainfall: Math.round(400 + Math.random() * 400),
            prop_idp: Math.round((0.1 + Math.random() * 0.2) * 100) / 100,
            sam_rate: Math.round((0.5 + Math.random() * 1.0) * 10) / 10,
            vaccination_coverage: Math.round(65 + Math.random() * 25),
          })
        })
      })

      return data
    }

    setHistoricalData(generateHistoricalData())
  }, [])

  const filteredData = historicalData.filter((item) => {
    const yearMatch = item.year === selectedYear
    const regionMatch = selectedRegion === "All" || item.region === selectedRegion
    return yearMatch && regionMatch
  })

  const getYearData = (year: number) => {
    return historicalData.filter((item) => item.year === year)
  }

  const calculateTotals = (data: HistoricalDataPoint[]) => {
    return data.reduce(
      (acc, item) => ({
        population: acc.population + item.population,
        measles: acc.measles + item.measles_cases,
        malaria: acc.malaria + item.malaria_cases,
        cholera: acc.cholera + item.cholera_cases,
      }),
      { population: 0, measles: 0, malaria: 0, cholera: 0 },
    )
  }

  const calculateGrowthRate = (currentYear: number, previousYear: number, disease: string) => {
    const current = getYearData(currentYear)
    const previous = getYearData(previousYear)

    if (current.length === 0 || previous.length === 0) return 0

    const currentTotal = calculateTotals(current)
    const previousTotal = calculateTotals(previous)

    const currentValue = currentTotal[disease as keyof typeof currentTotal]
    const previousValue = previousTotal[disease as keyof typeof previousTotal]

    if (previousValue === 0) return 0
    return ((currentValue - previousValue) / previousValue) * 100
  }

  const handleRefresh = () => {
    setIsLoading(true)
    setTimeout(() => {
      // Regenerate data with new random variations
      const newData = historicalData.map((item) => ({
        ...item,
        measles_cases: Math.round(item.measles_cases * (0.9 + Math.random() * 0.2)),
        malaria_cases: Math.round(item.malaria_cases * (0.9 + Math.random() * 0.2)),
        cholera_cases: Math.round(item.cholera_cases * (0.9 + Math.random() * 0.2)),
      }))
      setHistoricalData(newData)
      setIsLoading(false)
    }, 1000)
  }

  const handleExport = () => {
    const csvContent = [
      "Year,Region,District,Population,Measles Cases,Malaria Cases,Cholera Cases,Quality Score,Rainfall,IDP Proportion,SAM Rate,Vaccination Coverage",
      ...filteredData.map((item) =>
        [
          item.year,
          item.region,
          item.district,
          item.population,
          item.measles_cases,
          item.malaria_cases,
          item.cholera_cases,
          item.quality_score,
          item.rainfall,
          item.prop_idp,
          item.sam_rate,
          item.vaccination_coverage,
        ].join(","),
      ),
    ].join("\n")

    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `somalia_disease_data_${selectedYear}_${selectedRegion}.csv`
    a.click()
    window.URL.revokeObjectURL(url)
  }

  const yearTotals = calculateTotals(getYearData(selectedYear))

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-6 w-6" />
            Historical Disease Data (2020-2024)
          </CardTitle>
          <CardDescription>
            Comprehensive historical data for disease cases across Somalia regions with environmental and health
            indicators
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center gap-2">
              <MapPin className="h-4 w-4" />
              <span className="font-medium">6 Major Regions</span>
            </div>
            <div className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              <span className="font-medium">5 Years of Data</span>
            </div>
            <div className="flex items-center gap-2">
              <Activity className="h-4 w-4" />
              <span className="font-medium">12+ Health Indicators</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Controls */}
      <Card>
        <CardHeader>
          <CardTitle>Data Filters & Controls</CardTitle>
          <CardDescription>Filter historical data by year and region</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap items-center gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Year</label>
              <Select value={selectedYear.toString()} onValueChange={(value) => setSelectedYear(Number(value))}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {years.map((year) => (
                    <SelectItem key={year} value={year.toString()}>
                      {year}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Region</label>
              <Select value={selectedRegion} onValueChange={setSelectedRegion}>
                <SelectTrigger className="w-48">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {regions.map((region) => (
                    <SelectItem key={region} value={region}>
                      {region}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex gap-2 ml-auto">
              <Button onClick={handleRefresh} disabled={isLoading} variant="outline" size="sm">
                <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? "animate-spin" : ""}`} />
                Refresh
              </Button>
              <Button onClick={handleExport} variant="outline" size="sm">
                <Download className="h-4 w-4 mr-2" />
                Export CSV
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Year Overview Cards */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        {years.map((year) => {
          const yearData = calculateTotals(getYearData(year))
          const isSelected = year === selectedYear
          return (
            <Card
              key={year}
              className={`cursor-pointer transition-all hover:shadow-md ${
                isSelected ? "ring-2 ring-blue-500 bg-blue-50" : ""
              }`}
              onClick={() => setSelectedYear(year)}
            >
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">{year}</CardTitle>
                <Badge variant={isSelected ? "default" : "secondary"}>{yearData.population.toLocaleString()} pop</Badge>
              </CardHeader>
              <CardContent>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span>Measles:</span>
                    <span className="font-medium">{yearData.measles.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Malaria:</span>
                    <span className="font-medium">{yearData.malaria.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Cholera:</span>
                    <span className="font-medium">{yearData.cholera.toLocaleString()}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Main Data Display */}
      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="detailed">Detailed Data</TabsTrigger>
          <TabsTrigger value="trends">Trends</TabsTrigger>
          <TabsTrigger value="indicators">Health Indicators</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Total Population */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Total Population</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{yearTotals.population.toLocaleString()}</div>
                <p className="text-xs text-gray-600">Across {filteredData.length} regions</p>
              </CardContent>
            </Card>

            {/* Measles Cases */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-red-600">Measles Cases</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-red-600">{yearTotals.measles.toLocaleString()}</div>
                <div className="flex items-center gap-1 mt-1">
                  {calculateGrowthRate(selectedYear, selectedYear - 1, "measles") > 0 ? (
                    <TrendingUp className="h-3 w-3 text-red-500" />
                  ) : (
                    <TrendingUp className="h-3 w-3 text-green-500 rotate-180" />
                  )}
                  <span className="text-xs">
                    {Math.abs(calculateGrowthRate(selectedYear, selectedYear - 1, "measles")).toFixed(1)}% vs prev year
                  </span>
                </div>
              </CardContent>
            </Card>

            {/* Malaria Cases */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-yellow-600">Malaria Cases</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-yellow-600">{yearTotals.malaria.toLocaleString()}</div>
                <div className="flex items-center gap-1 mt-1">
                  {calculateGrowthRate(selectedYear, selectedYear - 1, "malaria") > 0 ? (
                    <TrendingUp className="h-3 w-3 text-red-500" />
                  ) : (
                    <TrendingUp className="h-3 w-3 text-green-500 rotate-180" />
                  )}
                  <span className="text-xs">
                    {Math.abs(calculateGrowthRate(selectedYear, selectedYear - 1, "malaria")).toFixed(1)}% vs prev year
                  </span>
                </div>
              </CardContent>
            </Card>

            {/* Cholera Cases */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-blue-600">Cholera Cases</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-600">{yearTotals.cholera.toLocaleString()}</div>
                <div className="flex items-center gap-1 mt-1">
                  {calculateGrowthRate(selectedYear, selectedYear - 1, "cholera") > 0 ? (
                    <TrendingUp className="h-3 w-3 text-red-500" />
                  ) : (
                    <TrendingUp className="h-3 w-3 text-green-500 rotate-180" />
                  )}
                  <span className="text-xs">
                    {Math.abs(calculateGrowthRate(selectedYear, selectedYear - 1, "cholera")).toFixed(1)}% vs prev year
                  </span>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Detailed Data Tab */}
        <TabsContent value="detailed">
          <Card>
            <CardHeader>
              <CardTitle>Detailed Regional Data - {selectedYear}</CardTitle>
              <CardDescription>
                Complete dataset for {selectedRegion === "All" ? "all regions" : selectedRegion}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left p-2">Region</th>
                      <th className="text-right p-2">Population</th>
                      <th className="text-right p-2">Measles</th>
                      <th className="text-right p-2">Malaria</th>
                      <th className="text-right p-2">Cholera</th>
                      <th className="text-right p-2">Quality Score</th>
                      <th className="text-right p-2">Rainfall</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredData.map((item, index) => (
                      <tr key={index} className="border-b hover:bg-gray-50">
                        <td className="p-2 font-medium">{item.region}</td>
                        <td className="p-2 text-right">{item.population.toLocaleString()}</td>
                        <td className="p-2 text-right text-red-600">{item.measles_cases.toLocaleString()}</td>
                        <td className="p-2 text-right text-yellow-600">{item.malaria_cases.toLocaleString()}</td>
                        <td className="p-2 text-right text-blue-600">{item.cholera_cases.toLocaleString()}</td>
                        <td className="p-2 text-right">{item.quality_score}</td>
                        <td className="p-2 text-right">{item.rainfall}mm</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Trends Tab */}
        <TabsContent value="trends">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {["measles", "malaria", "cholera"].map((disease) => (
              <Card key={disease}>
                <CardHeader>
                  <CardTitle className="capitalize">{disease} Trends</CardTitle>
                  <CardDescription>5-year progression analysis</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {years.map((year) => {
                      const yearData = calculateTotals(getYearData(year))
                      const value = yearData[disease as keyof typeof yearData]
                      const maxValue = Math.max(
                        ...years.map((y) => calculateTotals(getYearData(y))[disease as keyof typeof yearData]),
                      )
                      const percentage = (value / maxValue) * 100

                      return (
                        <div key={year} className="space-y-1">
                          <div className="flex justify-between text-sm">
                            <span>{year}</span>
                            <span className="font-medium">{value.toLocaleString()}</span>
                          </div>
                          <Progress value={percentage} className="h-2" />
                        </div>
                      )
                    })}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Health Indicators Tab */}
        <TabsContent value="indicators">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredData.map((item, index) => (
              <Card key={index}>
                <CardHeader>
                  <CardTitle className="text-lg">{item.region} Region</CardTitle>
                  <CardDescription>Health and environmental indicators for {selectedYear}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Quality Score:</span>
                        <Badge variant={item.quality_score > 80 ? "default" : "secondary"}>{item.quality_score}</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span>Vaccination:</span>
                        <span className="font-medium">{item.vaccination_coverage}%</span>
                      </div>
                      <div className="flex justify-between">
                        <span>SAM Rate:</span>
                        <span className="font-medium">{item.sam_rate}%</span>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Rainfall:</span>
                        <span className="font-medium">{item.rainfall}mm</span>
                      </div>
                      <div className="flex justify-between">
                        <span>IDP Proportion:</span>
                        <span className="font-medium">{(item.prop_idp * 100).toFixed(1)}%</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Population:</span>
                        <span className="font-medium">{(item.population / 1000).toFixed(0)}K</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      {/* Data Quality Alert */}
      <Alert>
        <CheckCircle className="h-4 w-4" />
        <AlertDescription>
          <strong>Data Quality:</strong> This historical dataset contains {historicalData.length} data points across 6
          regions and 5 years (2020-2024). Data includes population demographics, disease cases, environmental factors,
          and health system indicators. Perfect for training ML models and thesis research.
        </AlertDescription>
      </Alert>
    </div>
  )
}

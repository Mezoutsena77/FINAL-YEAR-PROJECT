"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Plus, Trash2, Download, Upload, Database, X } from "lucide-react"
import { useAuth } from "@/contexts/auth-context"
import { dataStorage, type DiseaseDataEntry } from "@/lib/data-storage"

interface DataManagementModalProps {
  isOpen: boolean
  onClose: () => void
}

export function DataManagementModal({ isOpen, onClose }: DataManagementModalProps) {
  const { user } = useAuth()
  const [dataEntries, setDataEntries] = useState<DiseaseDataEntry[]>([])
  const [isAddingData, setIsAddingData] = useState(false)
  const [editingEntry, setEditingEntry] = useState<DiseaseDataEntry | null>(null)
  const [newEntry, setNewEntry] = useState({
    region: "",
    district: "",
    year: 2024,
    measles_cases: 0,
    malaria_cases: 0,
    cholera_cases: 0,
    population: 0,
    source: "",
    notes: "",
  })

  const regions = [
    "Awdal",
    "Bakool",
    "Banadir",
    "Bari",
    "Bay",
    "Galgaduud",
    "Gedo",
    "Hiraan",
    "Lower Juba",
    "Lower Shabelle",
    "Middle Shabelle",
    "Mudug",
    "Nugaal",
    "Sanaag",
    "Sool",
    "Togdheer",
    "Woqooyi Galbeed",
  ]

  useEffect(() => {
    if (isOpen) {
      loadData()
    }
  }, [isOpen])

  const loadData = () => {
    setDataEntries(dataStorage.getData())
  }

  const handleAddData = () => {
    if (!user || !newEntry.region || !newEntry.district) return

    dataStorage.addData({
      ...newEntry,
      added_by: user.name,
    })

    loadData()
    setNewEntry({
      region: "",
      district: "",
      year: 2024,
      measles_cases: 0,
      malaria_cases: 0,
      cholera_cases: 0,
      population: 0,
      source: "",
      notes: "",
    })
    setIsAddingData(false)
  }

  const handleDeleteEntry = (id: string) => {
    if (confirm("Are you sure you want to delete this data entry?")) {
      dataStorage.deleteData(id)
      loadData()
    }
  }

  const handleExportData = () => {
    const data = dataStorage.exportData()
    const blob = new Blob([data], { type: "application/json" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `disease-data-${new Date().toISOString().split("T")[0]}.json`
    a.click()
    URL.revokeObjectURL(url)
  }

  const handleImportData = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onload = (e) => {
      try {
        const data = e.target?.result as string
        if (dataStorage.importData(data)) {
          loadData()
          alert("Data imported successfully!")
        } else {
          alert("Failed to import data. Invalid file format.")
        }
      } catch {
        alert("Failed to import data. Invalid file format.")
      }
    }
    reader.readAsText(file)
  }

  const canManageData = user?.role === "teacher" || user?.role === "supervisor" || user?.role === "admin"

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] flex flex-col">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <div>
              <DialogTitle className="flex items-center gap-2">
                <Database className="h-5 w-5" />
                Disease Data Management
              </DialogTitle>
              <DialogDescription>Manage disease surveillance data for Somalia - BIT28 Project</DialogDescription>
            </div>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>

        <Tabs defaultValue="view" className="flex-1 flex flex-col">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="view">View Data ({dataEntries.length})</TabsTrigger>
            <TabsTrigger value="add" disabled={!canManageData}>
              Add Data
            </TabsTrigger>
            <TabsTrigger value="manage" disabled={!canManageData}>
              Manage
            </TabsTrigger>
          </TabsList>

          <TabsContent value="view" className="flex-1 flex flex-col">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold">Current Data Entries</h3>
              <Button onClick={handleExportData} size="sm">
                <Download className="h-4 w-4 mr-2" />
                Export Data
              </Button>
            </div>

            <ScrollArea className="flex-1">
              <div className="space-y-2">
                {dataEntries.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <Database className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>No data entries found. Teachers can add new data using the "Add Data" tab.</p>
                  </div>
                ) : (
                  dataEntries.map((entry) => (
                    <div key={entry.id} className="border rounded-lg p-4">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <h4 className="font-semibold">
                            {entry.district}, {entry.region}
                          </h4>
                          <p className="text-sm text-gray-600">Year: {entry.year}</p>
                        </div>
                        <div className="flex gap-2">
                          <Badge variant="outline">{entry.source}</Badge>
                          {canManageData && (
                            <Button size="sm" variant="outline" onClick={() => handleDeleteEntry(entry.id)}>
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                      </div>

                      <div className="grid grid-cols-4 gap-4 text-sm">
                        <div>
                          <span className="font-medium text-red-600">Measles:</span>
                          <div className="text-lg font-bold">{entry.measles_cases.toLocaleString()}</div>
                        </div>
                        <div>
                          <span className="font-medium text-yellow-600">Malaria:</span>
                          <div className="text-lg font-bold">{entry.malaria_cases.toLocaleString()}</div>
                        </div>
                        <div>
                          <span className="font-medium text-blue-600">Cholera:</span>
                          <div className="text-lg font-bold">{entry.cholera_cases.toLocaleString()}</div>
                        </div>
                        <div>
                          <span className="font-medium text-gray-600">Population:</span>
                          <div className="text-lg font-bold">{entry.population.toLocaleString()}</div>
                        </div>
                      </div>

                      <div className="mt-2 text-xs text-gray-500">
                        Added by {entry.added_by} on {new Date(entry.date_added).toLocaleDateString()}
                        {entry.notes && <div className="mt-1">Notes: {entry.notes}</div>}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="add" className="space-y-4">
            {!canManageData ? (
              <Alert>
                <AlertDescription>Only teachers, supervisors, and administrators can add data.</AlertDescription>
              </Alert>
            ) : (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Add New Disease Data</h3>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="region">Region</Label>
                    <Select
                      value={newEntry.region}
                      onValueChange={(value) => setNewEntry({ ...newEntry, region: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select region" />
                      </SelectTrigger>
                      <SelectContent>
                        {regions.map((region) => (
                          <SelectItem key={region} value={region}>
                            {region}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="district">District</Label>
                    <Input
                      id="district"
                      value={newEntry.district}
                      onChange={(e) => setNewEntry({ ...newEntry, district: e.target.value })}
                      placeholder="Enter district name"
                    />
                  </div>

                  <div>
                    <Label htmlFor="year">Year</Label>
                    <Input
                      id="year"
                      type="number"
                      value={newEntry.year}
                      onChange={(e) => setNewEntry({ ...newEntry, year: Number.parseInt(e.target.value) || 2024 })}
                      min={2020}
                      max={2030}
                    />
                  </div>

                  <div>
                    <Label htmlFor="population">Population</Label>
                    <Input
                      id="population"
                      type="number"
                      value={newEntry.population}
                      onChange={(e) => setNewEntry({ ...newEntry, population: Number.parseInt(e.target.value) || 0 })}
                      min={0}
                    />
                  </div>

                  <div>
                    <Label htmlFor="measles">Measles Cases</Label>
                    <Input
                      id="measles"
                      type="number"
                      value={newEntry.measles_cases}
                      onChange={(e) =>
                        setNewEntry({ ...newEntry, measles_cases: Number.parseInt(e.target.value) || 0 })
                      }
                      min={0}
                    />
                  </div>

                  <div>
                    <Label htmlFor="malaria">Malaria Cases</Label>
                    <Input
                      id="malaria"
                      type="number"
                      value={newEntry.malaria_cases}
                      onChange={(e) =>
                        setNewEntry({ ...newEntry, malaria_cases: Number.parseInt(e.target.value) || 0 })
                      }
                      min={0}
                    />
                  </div>

                  <div>
                    <Label htmlFor="cholera">Cholera Cases</Label>
                    <Input
                      id="cholera"
                      type="number"
                      value={newEntry.cholera_cases}
                      onChange={(e) =>
                        setNewEntry({ ...newEntry, cholera_cases: Number.parseInt(e.target.value) || 0 })
                      }
                      min={0}
                    />
                  </div>

                  <div>
                    <Label htmlFor="source">Data Source</Label>
                    <Input
                      id="source"
                      value={newEntry.source}
                      onChange={(e) => setNewEntry({ ...newEntry, source: e.target.value })}
                      placeholder="e.g., Ministry of Health, WHO, Field Survey"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="notes">Notes (Optional)</Label>
                  <Textarea
                    id="notes"
                    value={newEntry.notes}
                    onChange={(e) => setNewEntry({ ...newEntry, notes: e.target.value })}
                    placeholder="Additional notes about this data entry..."
                    rows={3}
                  />
                </div>

                <Button onClick={handleAddData} className="w-full">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Data Entry
                </Button>
              </div>
            )}
          </TabsContent>

          <TabsContent value="manage" className="space-y-4">
            {!canManageData ? (
              <Alert>
                <AlertDescription>Only teachers, supervisors, and administrators can manage data.</AlertDescription>
              </Alert>
            ) : (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Data Management</h3>

                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 border rounded-lg">
                    <h4 className="font-semibold mb-2">Import Data</h4>
                    <p className="text-sm text-gray-600 mb-3">Import data from JSON file</p>
                    <input type="file" accept=".json" onChange={handleImportData} className="hidden" id="import-data" />
                    <Button asChild variant="outline" className="w-full bg-transparent">
                      <label htmlFor="import-data" className="cursor-pointer">
                        <Upload className="h-4 w-4 mr-2" />
                        Import Data
                      </label>
                    </Button>
                  </div>

                  <div className="p-4 border rounded-lg">
                    <h4 className="font-semibold mb-2">Export Data</h4>
                    <p className="text-sm text-gray-600 mb-3">Download all data as JSON</p>
                    <Button onClick={handleExportData} variant="outline" className="w-full bg-transparent">
                      <Download className="h-4 w-4 mr-2" />
                      Export All Data
                    </Button>
                  </div>
                </div>

                <Alert>
                  <AlertDescription>
                    <strong>Data Statistics:</strong>
                    <br />
                    Total Entries: {dataEntries.length}
                    <br />
                    Total Measles Cases:{" "}
                    {dataEntries.reduce((sum, entry) => sum + entry.measles_cases, 0).toLocaleString()}
                    <br />
                    Total Malaria Cases:{" "}
                    {dataEntries.reduce((sum, entry) => sum + entry.malaria_cases, 0).toLocaleString()}
                    <br />
                    Total Cholera Cases:{" "}
                    {dataEntries.reduce((sum, entry) => sum + entry.cholera_cases, 0).toLocaleString()}
                  </AlertDescription>
                </Alert>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}

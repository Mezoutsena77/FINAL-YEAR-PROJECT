"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Database, Download, Eye, EyeOff } from "lucide-react"
import { authStorage } from "@/lib/auth-storage"

export function DatabaseManager() {
  const [showPasswords, setShowPasswords] = useState(false)
  const [users, setUsers] = useState(authStorage.getUsers())

  const refreshUsers = () => {
    setUsers(authStorage.getUsers())
  }

  const exportToJSON = () => {
    const data = authStorage.exportUsers()
    const blob = new Blob([data], { type: "application/json" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `disease-dashboard-users-${new Date().toISOString().split("T")[0]}.json`
    a.click()
    URL.revokeObjectURL(url)
  }

  const exportToCSV = () => {
    const headers = ["ID", "Name", "Email", "Role", "Password", "Created At"]
    const csvContent = [
      headers.join(","),
      ...users.map((user) =>
        [user.id, user.name, user.email, user.role, user.password, user.createdAt]
          .map((field) => `"${field}"`)
          .join(","),
      ),
    ].join("\n")

    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `disease-dashboard-users-${new Date().toISOString().split("T")[0]}.csv`
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5" />
            Local Database Manager
          </CardTitle>
          <CardDescription>View and manage your local user database</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert>
            <AlertDescription>
              <strong>Storage Location:</strong> Browser localStorage (key: "disease_dashboard_users")
              <br />
              <strong>Current Users:</strong> {users.length} accounts
            </AlertDescription>
          </Alert>

          <div className="flex gap-2 flex-wrap">
            <Button onClick={exportToJSON} variant="outline">
              <Download className="h-4 w-4 mr-2" />
              Export JSON
            </Button>
            <Button onClick={exportToCSV} variant="outline">
              <Download className="h-4 w-4 mr-2" />
              Export CSV
            </Button>
            <Button onClick={refreshUsers} variant="outline">
              <Database className="h-4 w-4 mr-2" />
              Refresh
            </Button>
            <Button onClick={() => setShowPasswords(!showPasswords)} variant="outline">
              {showPasswords ? <EyeOff className="h-4 w-4 mr-2" /> : <Eye className="h-4 w-4 mr-2" />}
              {showPasswords ? "Hide" : "Show"} Passwords
            </Button>
          </div>

          <div className="border rounded-lg p-4 bg-gray-50 max-h-96 overflow-auto">
            <h4 className="font-semibold mb-2">Current Users Database:</h4>
            <pre className="text-xs text-gray-700 whitespace-pre-wrap">
              {JSON.stringify(
                users.map((user) => ({
                  ...user,
                  password: showPasswords ? user.password : "***hidden***",
                })),
                null,
                2,
              )}
            </pre>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

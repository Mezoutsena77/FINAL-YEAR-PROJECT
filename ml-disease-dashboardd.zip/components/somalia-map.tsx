"use client"

import { useEffect, useRef } from "react"

interface SomaliaMapProps {
  selectedDisease: string
}

export function SomaliaMap({ selectedDisease }: SomaliaMapProps) {
  const mapRef = useRef<HTMLDivElement>(null)
  const mapInstanceRef = useRef<any>(null)

  useEffect(() => {
    // Load Leaflet dynamically
    const loadLeaflet = async () => {
      if (typeof window === "undefined") return

      // Load Leaflet CSS
      if (!document.querySelector('link[href*="leaflet.css"]')) {
        const link = document.createElement("link")
        link.rel = "stylesheet"
        link.href = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
        link.integrity = "sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY="
        link.crossOrigin = ""
        document.head.appendChild(link)
      }

      // Load Leaflet JS
      if (!window.L) {
        return new Promise((resolve) => {
          const script = document.createElement("script")
          script.src = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"
          script.integrity = "sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo="
          script.crossOrigin = ""
          script.onload = resolve
          document.head.appendChild(script)
        })
      }
    }

    const initializeMap = async () => {
      await loadLeaflet()

      if (!mapRef.current || !window.L) return

      // Remove existing map if any
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove()
      }

      // Initialize map
      const map = window.L.map(mapRef.current).setView([5.1521, 46.1996], 6)
      mapInstanceRef.current = map

      // Add tile layer
      window.L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: "© OpenStreetMap contributors",
        maxZoom: 18,
      }).addTo(map)

      // Real district data from Somalia with updated rounded numbers
      const districts = [
        // Awdal Region
        { name: "Baki", lat: 10.9167, lng: 43.25, measles: 112, malaria: 12227, cholera: 0, region: "Awdal" },
        { name: "Borama", lat: 9.9333, lng: 43.2167, measles: 125, malaria: 31681, cholera: 0, region: "Awdal" },
        { name: "Lughaye", lat: 10.6333, lng: 43.9, measles: 142, malaria: 12299, cholera: 0, region: "Awdal" },
        { name: "Zeylac", lat: 11.35, lng: 43.4667, measles: 95, malaria: 9039, cholera: 0, region: "Awdal" },

        // Bakool Region
        { name: "Ceel Barde", lat: 4.1, lng: 43.7, measles: 0, malaria: 124, cholera: 289, region: "Bakool" },
        { name: "Waajid", lat: 3.8, lng: 43.5, measles: 0, malaria: 345, cholera: 4056, region: "Bakool" },
        { name: "Xudur", lat: 4.1167, lng: 43.8833, measles: 834, malaria: 16657, cholera: 44, region: "Bakool" },

        // Banadir Region
        {
          name: "Banadir",
          lat: 2.0469,
          lng: 45.3182,
          measles: 577188,
          malaria: 158099,
          cholera: 659715,
          region: "Banadir",
        },

        // Bari Region
        { name: "Bandarbeyla", lat: 9.4833, lng: 50.8167, measles: 1243, malaria: 604, cholera: 63, region: "Bari" },
        {
          name: "Bossaso",
          lat: 11.2842,
          lng: 49.1816,
          measles: 98291,
          malaria: 112030,
          cholera: 275850,
          region: "Bari",
        },
        { name: "Caluula", lat: 11.9667, lng: 50.75, measles: 3201, malaria: 994, cholera: 3, region: "Bari" },
        { name: "Iskushuban", lat: 10.2833, lng: 50.2333, measles: 3801, malaria: 1634, cholera: 58, region: "Bari" },
        { name: "Qandala", lat: 11.4667, lng: 49.8667, measles: 3592, malaria: 799, cholera: 7, region: "Bari" },
        { name: "Qardho", lat: 11.0167, lng: 49.0667, measles: 6187, malaria: 3459, cholera: 0, region: "Bari" },

        // Bay Region
        { name: "Baidoa", lat: 3.114, lng: 43.65, measles: 150730, malaria: 88047, cholera: 73216, region: "Bay" },
        {
          name: "Burhakaba",
          lat: 2.7833,
          lng: 44.0833,
          measles: 717690,
          malaria: 155883,
          cholera: 300719,
          region: "Bay",
        },
        { name: "Dinsoor", lat: 2.4167, lng: 42.9833, measles: 72459, malaria: 26000, cholera: 0, region: "Bay" },

        // Galgaduud Region
        { name: "Adado", lat: 4.75, lng: 46.4833, measles: 29988, malaria: 80000, cholera: 10000, region: "Galgaduud" },
        {
          name: "Dhuusamarreeb",
          lat: 5.5333,
          lng: 46.3833,
          measles: 150,
          malaria: 427,
          cholera: 169337,
          region: "Galgaduud",
        },
        { name: "Guriel", lat: 4.7167, lng: 45.9, measles: 718, malaria: 0, cholera: 0, region: "Galgaduud" },

        // Gedo Region
        { name: "Bardera", lat: 2.3333, lng: 42.2833, measles: 5000, malaria: 13000, cholera: 3000, region: "Gedo" },
        { name: "El Wak", lat: 2.8, lng: 40.9167, measles: 654, malaria: 20000, cholera: 0, region: "Gedo" },
        { name: "Luuq", lat: 3.8, lng: 42.55, measles: 10000, malaria: 50000, cholera: 15000, region: "Gedo" },

        // Hiraan Region
        {
          name: "Beletweyne",
          lat: 4.7333,
          lng: 45.2,
          measles: 20000,
          malaria: 20000,
          cholera: 20000,
          region: "Hiraan",
        },
        { name: "Mahas", lat: 4.1167, lng: 45.5167, measles: 30051, malaria: 19834, cholera: 41713, region: "Hiraan" },

        // Lower Juba Region
        {
          name: "Kismayo",
          lat: -0.3582,
          lng: 42.5454,
          measles: 51000,
          malaria: 50613,
          cholera: 12340,
          region: "Lower Juba",
        },
        {
          name: "Jamaame",
          lat: -0.0667,
          lng: 42.75,
          measles: 100000,
          malaria: 40000,
          cholera: 210000,
          region: "Lower Juba",
        },

        // Lower Shabelle Region
        {
          name: "Marka",
          lat: 1.7167,
          lng: 44.7667,
          measles: 400,
          malaria: 800,
          cholera: 300,
          region: "Lower Shabelle",
        },
        {
          name: "Qoryooley",
          lat: 1.7833,
          lng: 44.5333,
          measles: 221,
          malaria: 385,
          cholera: 275,
          region: "Lower Shabelle",
        },

        // Middle Shabelle Region
        {
          name: "Jowhar",
          lat: 2.7667,
          lng: 45.5,
          measles: 1096,
          malaria: 2123,
          cholera: 1113,
          region: "Middle Shabelle",
        },
        { name: "Adale", lat: 2.75, lng: 46.3333, measles: 0, malaria: 0, cholera: 0, region: "Middle Shabelle" },

        // Mudug Region
        { name: "Gaalkacyo", lat: 6.77, lng: 47.43, measles: 150000, malaria: 20000, cholera: 200000, region: "Mudug" },
        { name: "Hobyo", lat: 5.35, lng: 48.5333, measles: 14925, malaria: 6457, cholera: 52556, region: "Mudug" },

        // Nugaal Region
        { name: "Garowe", lat: 8.402, lng: 48.4845, measles: 50000, malaria: 5101, cholera: 139345, region: "Nugaal" },
        { name: "Eyl", lat: 7.9833, lng: 49.8167, measles: 3487, malaria: 0, cholera: 0, region: "Nugaal" },

        // Sanaag Region
        { name: "Ceel Afweyn", lat: 9.8, lng: 46.6, measles: 20, malaria: 470, cholera: 9, region: "Sanaag" },
        { name: "Ceerigaabo", lat: 10.6167, lng: 47.3667, measles: 192, malaria: 2481, cholera: 31, region: "Sanaag" },
        { name: "Laasqoray", lat: 11.2167, lng: 48.1667, measles: 33, malaria: 460, cholera: 5, region: "Sanaag" },

        // Sool Region
        { name: "Caynabo", lat: 9.4, lng: 46.3, measles: 0, malaria: 100, cholera: 6, region: "Sool" },
        { name: "Laas Caanood", lat: 8.4833, lng: 47.35, measles: 149, malaria: 679, cholera: 9, region: "Sool" },
        { name: "Taleex", lat: 8.8667, lng: 47.7333, measles: 0, malaria: 84, cholera: 0, region: "Sool" },
        { name: "Xudun", lat: 8.3833, lng: 46.8833, measles: 0, malaria: 284, cholera: 6, region: "Sool" },

        // Togdheer Region
        { name: "Burco", lat: 9.5205, lng: 45.5347, measles: 1692, malaria: 9292, cholera: 0, region: "Togdheer" },
        { name: "Buuhoodle", lat: 8.8167, lng: 46.0833, measles: 164, malaria: 286, cholera: 0, region: "Togdheer" },
        { name: "Owdweyne", lat: 9.5, lng: 45.0667, measles: 260, malaria: 2511, cholera: 0, region: "Togdheer" },
        { name: "Sheikh", lat: 9.9333, lng: 45.7, measles: 7, malaria: 5153, cholera: 0, region: "Togdheer" },

        // Woqooyi Galbeed Region
        {
          name: "Berbera",
          lat: 10.4396,
          lng: 45.0143,
          measles: 54,
          malaria: 10684,
          cholera: 0,
          region: "Woqooyi Galbeed",
        },
        {
          name: "Gebiley",
          lat: 9.5833,
          lng: 43.8333,
          measles: 104,
          malaria: 34176,
          cholera: 0,
          region: "Woqooyi Galbeed",
        },
        {
          name: "Hargeysa",
          lat: 9.56,
          lng: 44.065,
          measles: 6010,
          malaria: 251138,
          cholera: 79495,
          region: "Woqooyi Galbeed",
        },
      ]

      // Add markers for each district
      districts.forEach((district) => {
        const cases = district[selectedDisease as keyof typeof district] as number
        const color = selectedDisease === "measles" ? "#ef4444" : selectedDisease === "malaria" ? "#eab308" : "#3b82f6"

        const radius = Math.max(8, Math.min(25, cases / 30))

        const marker = window.L.circleMarker([district.lat, district.lng], {
          radius: radius,
          fillColor: color,
          color: "#ffffff",
          weight: 2,
          opacity: 0.9,
          fillOpacity: 0.7,
        })

        marker.bindPopup(`
          <div style="padding: 8px; min-width: 200px;">
            <h3 style="margin: 0 0 8px 0; font-weight: bold; color: #1f2937;">${district.name}</h3>
            <div style="display: flex; flex-direction: column; gap: 4px;">
              <div style="display: flex; justify-content: space-between;">
                <span style="color: #ef4444;">🔴 Measles:</span>
                <strong>${district.measles} cases</strong>
              </div>
              <div style="display: flex; justify-content: space-between;">
                <span style="color: #eab308;">🟡 Malaria:</span>
                <strong>${district.malaria} cases</strong>
              </div>
              <div style="display: flex; justify-content: space-between;">
                <span style="color: #3b82f6;">🔵 Cholera:</span>
                <strong>${district.cholera} cases</strong>
              </div>
            </div>
          </div>
        `)

        marker.addTo(map)
      })

      // Add a legend
      const legend = window.L.control({ position: "bottomright" })
      legend.onAdd = () => {
        const div = window.L.DomUtil.create("div", "info legend")
        div.style.backgroundColor = "white"
        div.style.padding = "10px"
        div.style.borderRadius = "5px"
        div.style.boxShadow = "0 2px 4px rgba(0,0,0,0.1)"

        const diseaseColors = {
          measles: "#ef4444",
          malaria: "#eab308",
          cholera: "#3b82f6",
        }

        div.innerHTML = `
          <h4 style="margin: 0 0 8px 0; font-size: 14px;">Disease Cases</h4>
          <div style="display: flex; flex-direction: column; gap: 4px; font-size: 12px;">
            <div style="display: flex; align-items: center; gap: 6px;">
              <div style="width: 12px; height: 12px; background: #ef4444; border-radius: 50%;"></div>
              <span>Measles</span>
            </div>
            <div style="display: flex; align-items: center; gap: 6px;">
              <div style="width: 12px; height: 12px; background: #eab308; border-radius: 50%;"></div>
              <span>Malaria</span>
            </div>
            <div style="display: flex; align-items: center; gap: 6px;">
              <div style="width: 12px; height: 12px; background: #3b82f6; border-radius: 50%;"></div>
              <span>Cholera</span>
            </div>
          </div>
          <div style="margin-top: 8px; font-size: 11px; color: #666;">
            Circle size = case count
          </div>
        `
        return div
      }
      legend.addTo(map)
    }

    initializeMap()

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove()
        mapInstanceRef.current = null
      }
    }
  }, [selectedDisease])

  return (
    <div className="relative">
      <div ref={mapRef} className="w-full h-96 rounded-lg border bg-gray-100" style={{ minHeight: "400px" }} />
      {!mapInstanceRef.current && (
        <div className="absolute inset-0 flex items-center justify-center bg-gray-100 rounded-lg">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-2"></div>
            <p className="text-sm text-gray-600">Loading map...</p>
          </div>
        </div>
      )}
    </div>
  )
}

import { Alert, AlertDescription } from "@/components/ui/alert"
import { Info, FileText } from "lucide-react"

export function DataAccuracyNote() {
  return (
    <Alert className="mb-6">
      <Info className="h-4 w-4" />
      <AlertDescription>
        <div className="flex items-center gap-2 mb-2">
          <FileText className="h-4 w-4" />
          <strong>Data Source:</strong> offer.csv - Annual disease surveillance data from Somalia health surveys
        </div>
        <div className="text-sm">
          Total cases from dataset: <span className="font-semibold text-red-600">2,133,115 Measles</span>,{" "}
          <span className="font-semibold text-yellow-600">1,520,541 Malaria</span>,{" "}
          <span className="font-semibold text-blue-600">2,311,288 Cholera</span>. Monthly trends are projected estimates
          for visualization purposes based on epidemiological patterns.
        </div>
      </AlertDescription>
    </Alert>
  )
}

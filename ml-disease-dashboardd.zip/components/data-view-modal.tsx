"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { X, Search, Download, ChevronLeft, ChevronRight, Database, CheckCircle, AlertCircle } from "lucide-react"

interface DataViewModalProps {
  isOpen: boolean
  onClose: () => void
}

interface CSVData {
  success: boolean
  message: string
  data: Record<string, string>[]
  columns: string[]
  totalRows?: number
  fileSize?: number
  filePath?: string
  isRealData: boolean
}

export function DataViewModal({ isOpen, onClose }: DataViewModalProps) {
  const [csvData, setCsvData] = useState<CSVData | null>(null)
  const [loading, setLoading] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [currentPage, setCurrentPage] = useState(1)
  const [loadingLog, setLoadingLog] = useState<string[]>([])
  const rowsPerPage = 50

  // Generate Excel-style column letters
  const getColumnLetter = (index: number): string => {
    let result = ""
    while (index >= 0) {
      result = String.fromCharCode(65 + (index % 26)) + result
      index = Math.floor(index / 26) - 1
    }
    return result
  }

  const loadCSVData = async () => {
    setLoading(true)
    setLoadingLog([])

    try {
      setLoadingLog((prev) => [...prev, "🔍 Searching for CSV files..."])

      const response = await fetch("/api/csv-data")
      const data: CSVData = await response.json()

      if (data.success) {
        setLoadingLog((prev) => [...prev, `✅ ${data.message}`])
        setLoadingLog((prev) => [...prev, `📊 Loaded ${data.data.length} rows with ${data.columns.length} columns`])
        if (data.fileSize) {
          setLoadingLog((prev) => [...prev, `📁 File size: ${(data.fileSize / 1024).toFixed(1)} KB`])
        }
      } else {
        setLoadingLog((prev) => [...prev, `⚠️ ${data.message}`])
      }

      setCsvData(data)
    } catch (error) {
      setLoadingLog((prev) => [...prev, `❌ Error loading CSV: ${error}`])
      setCsvData({
        success: false,
        message: "Failed to load CSV data",
        data: [],
        columns: [],
        isRealData: false,
      })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (isOpen) {
      loadCSVData()
    }
  }, [isOpen])

  // Filter data based on search term
  const filteredData =
    csvData?.data.filter((row) =>
      Object.values(row).some((value) => value.toString().toLowerCase().includes(searchTerm.toLowerCase())),
    ) || []

  // Paginate filtered data
  const totalPages = Math.ceil(filteredData.length / rowsPerPage)
  const startIndex = (currentPage - 1) * rowsPerPage
  const paginatedData = filteredData.slice(startIndex, startIndex + rowsPerPage)

  const exportCSV = () => {
    if (!csvData?.data.length) return

    const headers = csvData.columns.join(",")
    const rows = csvData.data.map((row) => csvData.columns.map((col) => `"${row[col] || ""}"`).join(",")).join("\n")

    const csvContent = `${headers}\n${rows}`
    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "somalia_survey_data.csv"
    a.click()
    URL.revokeObjectURL(url)
  }

  if (!isOpen) return null

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-[95vw] max-h-[95vh] w-full h-full p-0 overflow-hidden">
        <div className="flex flex-col h-full">
          {/* Header */}
          <DialogHeader className="flex-shrink-0 p-4 border-b bg-white">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Database className="h-6 w-6 text-blue-600" />
                <div>
                  <DialogTitle className="text-xl font-bold">Somalia SMART Survey Dataset</DialogTitle>
                  <p className="text-sm text-gray-600 mt-1">
                    {csvData?.isRealData
                      ? "51 districts across 17 regions of Somalia"
                      : "Sample data - place CSV at /public/data/offer.csv"}
                  </p>
                </div>
                {csvData && (
                  <Badge variant={csvData.isRealData ? "default" : "secondary"} className="ml-2">
                    {csvData.isRealData ? (
                      <>
                        <CheckCircle className="h-3 w-3 mr-1" /> Real Data
                      </>
                    ) : (
                      <>
                        <AlertCircle className="h-3 w-3 mr-1" /> Sample Data
                      </>
                    )}
                  </Badge>
                )}
              </div>
              <Button variant="ghost" size="sm" onClick={onClose}>
                <X className="h-4 w-4" />
              </Button>
            </div>
          </DialogHeader>

          {/* Loading Log */}
          {loading && (
            <div className="flex-shrink-0 p-3 bg-gray-50 border-b max-h-32 overflow-y-auto">
              <div className="space-y-1">
                {loadingLog.map((log, index) => (
                  <div key={index} className="text-xs font-mono text-gray-700">
                    {log}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Controls */}
          {csvData && (
            <div className="flex-shrink-0 p-3 border-b bg-white">
              <div className="flex items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <Input
                      placeholder="Search data..."
                      value={searchTerm}
                      onChange={(e) => {
                        setSearchTerm(e.target.value)
                        setCurrentPage(1)
                      }}
                      className="pl-10 w-64"
                    />
                  </div>
                  <Badge variant="outline">
                    {csvData.columns.length} columns × {filteredData.length} rows
                  </Badge>
                  <Badge variant="secondary">51 districts surveyed</Badge>
                </div>

                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm" onClick={exportCSV}>
                    <Download className="h-4 w-4 mr-2" />
                    Export CSV
                  </Button>
                </div>
              </div>
            </div>
          )}

          {/* Data Table Container with Fixed Scrolling */}
          {csvData && (
            <div className="flex-1 overflow-hidden bg-white">
              <div className="h-full overflow-auto">
                <div className="min-w-max">
                  <table className="w-full border-collapse bg-white">
                    {/* Column Headers - Sticky */}
                    <thead className="sticky top-0 bg-gray-100 z-20 shadow-sm">
                      <tr>
                        <th className="sticky left-0 bg-gray-200 border border-gray-300 px-2 py-2 text-xs font-semibold text-gray-700 min-w-[60px] z-30">
                          Row #
                        </th>
                        {csvData.columns.map((column, index) => (
                          <th
                            key={index}
                            className="border border-gray-300 px-3 py-2 text-left bg-gray-100 min-w-[140px] max-w-[200px]"
                          >
                            <div className="flex flex-col">
                              <span className="text-xs font-bold text-blue-600">{getColumnLetter(index)}</span>
                              <span className="text-xs text-gray-700 font-medium truncate" title={column}>
                                {column}
                              </span>
                            </div>
                          </th>
                        ))}
                      </tr>
                    </thead>

                    {/* Data Rows */}
                    <tbody>
                      {paginatedData.map((row, rowIndex) => (
                        <tr key={rowIndex} className="hover:bg-blue-50 transition-colors">
                          <td className="sticky left-0 bg-white border border-gray-300 px-2 py-2 text-xs text-gray-600 font-mono z-10 hover:bg-blue-50">
                            {startIndex + rowIndex + 1}
                          </td>
                          {csvData.columns.map((column, colIndex) => (
                            <td
                              key={colIndex}
                              className="border border-gray-300 px-3 py-2 text-sm max-w-[200px] bg-white"
                              title={row[column]}
                            >
                              <div className="truncate">
                                {row[column] || <span className="text-gray-400 italic">empty</span>}
                              </div>
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* Pagination */}
          {csvData && totalPages > 1 && (
            <div className="flex-shrink-0 p-3 border-t bg-gray-50">
              <div className="flex items-center justify-between">
                <div className="text-sm text-gray-600">
                  Showing {startIndex + 1} to {Math.min(startIndex + rowsPerPage, filteredData.length)} of{" "}
                  {filteredData.length} records
                  {csvData.totalRows && csvData.totalRows > filteredData.length && (
                    <span className="ml-2 text-gray-500">(Total: {csvData.totalRows.toLocaleString()} in dataset)</span>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentPage((prev) => Math.max(1, prev - 1))}
                    disabled={currentPage === 1}
                  >
                    <ChevronLeft className="h-4 w-4" />
                    Previous
                  </Button>

                  <span className="text-sm text-gray-600 px-2">
                    Page {currentPage} of {totalPages}
                  </span>

                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentPage((prev) => Math.min(totalPages, prev + 1))}
                    disabled={currentPage === totalPages}
                  >
                    Next
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          )}

          {/* No Data State */}
          {!loading && (!csvData || csvData.data.length === 0) && (
            <div className="flex-1 flex items-center justify-center bg-gray-50">
              <Card className="w-96">
                <CardContent className="text-center py-12">
                  <Database className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                  <h3 className="text-lg font-semibold mb-2">No Survey Data Found</h3>
                  <p className="text-gray-600 mb-4">
                    Place your SMART survey CSV file at{" "}
                    <code className="bg-gray-100 px-2 py-1 rounded text-sm">/public/data/offer.csv</code> to view the
                    complete dataset covering 51 districts across Somalia.
                  </p>
                  <Button onClick={loadCSVData} variant="outline">
                    <Database className="h-4 w-4 mr-2" />
                    Retry Loading
                  </Button>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}

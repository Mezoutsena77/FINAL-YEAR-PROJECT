"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { authStorage, type User } from "@/lib/auth-storage"

interface AuthContextType {
  user: User | null
  login: (email: string, password: string) => Promise<{ success: boolean; message: string }>
  register: (
    name: string,
    email: string,
    password: string,
    role: string,
  ) => Promise<{ success: boolean; message: string }>
  logout: () => void
  isLoading: boolean
  getAllUsers: () => User[]
  updateUserProfile: (updates: Partial<User>) => Promise<boolean>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

interface AuthProviderProps {
  children: ReactNode
}

export function AuthProvider({ children }: AuthProviderProps) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Check if user is logged in on app start
    const savedUser = localStorage.getItem("current_user")
    if (savedUser) {
      const userData = JSON.parse(savedUser)
      // Verify user still exists in storage
      const existingUser = authStorage.findUserByEmail(userData.email)
      if (existingUser) {
        setUser(existingUser)
      } else {
        localStorage.removeItem("current_user")
      }
    }
    setIsLoading(false)
  }, [])

  const login = async (email: string, password: string): Promise<{ success: boolean; message: string }> => {
    setIsLoading(true)

    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    try {
      const authenticatedUser = authStorage.authenticate(email, password)

      if (authenticatedUser) {
        // Remove password from user object for security
        const { password: _, ...userWithoutPassword } = authenticatedUser
        setUser(userWithoutPassword as User)
        localStorage.setItem("current_user", JSON.stringify(userWithoutPassword))
        setIsLoading(false)
        return { success: true, message: `Welcome back, ${authenticatedUser.name}!` }
      } else {
        setIsLoading(false)
        return { success: false, message: "Invalid email or password" }
      }
    } catch (error) {
      setIsLoading(false)
      return { success: false, message: "Login failed. Please try again." }
    }
  }

  const register = async (
    name: string,
    email: string,
    password: string,
    role: string,
  ): Promise<{ success: boolean; message: string }> => {
    setIsLoading(true)

    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 1500))

    try {
      // Check if email already exists
      if (authStorage.emailExists(email)) {
        setIsLoading(false)
        return { success: false, message: "Email already exists" }
      }

      // Create new user
      const newUser = authStorage.addUser({
        name,
        email,
        password,
        role: role as "admin" | "researcher" | "viewer" | "supervisor" | "teacher",
        class: "BIT28",
        position: "Student",
      })

      // Remove password from user object for security
      const { password: _, ...userWithoutPassword } = newUser
      setUser(userWithoutPassword as User)
      localStorage.setItem("current_user", JSON.stringify(userWithoutPassword))
      setIsLoading(false)
      return { success: true, message: "Account created successfully!" }
    } catch (error) {
      setIsLoading(false)
      return { success: false, message: "Registration failed. Please try again." }
    }
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem("current_user")
  }

  const getAllUsers = (): User[] => {
    return authStorage.getUsers()
  }

  const updateUserProfile = async (updates: Partial<User>): Promise<boolean> => {
    if (!user) return false

    try {
      const updatedUser = authStorage.updateUser(user.id, updates)
      if (updatedUser) {
        const { password: _, ...userWithoutPassword } = updatedUser
        setUser(userWithoutPassword as User)
        localStorage.setItem("current_user", JSON.stringify(userWithoutPassword))
        return true
      }
      return false
    } catch {
      return false
    }
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        login,
        register,
        logout,
        isLoading,
        getAllUsers,
        updateUserProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}
